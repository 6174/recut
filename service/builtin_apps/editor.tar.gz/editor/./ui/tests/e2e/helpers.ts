import type { Page } from "@playwright/test";

export function closeTo(received: number, expected: number, tolerance = 2): boolean {
	return Math.abs(received - expected) <= tolerance;
}

export async function openDemo(page: Page): Promise<void> {
	await page.goto("/demo.html?test=1");
	await page.waitForSelector("canvas[data-recut-canvas]", { timeout: 15_000 });
	await page.waitForFunction(
		() => (window as any).__recutTest?.getNodeBounds("demo-el-glow") != null,
		{ timeout: 15_000 },
	);
	await testGet(page, "setTime", 0);
	await testGet(page, "advanceFrame");
}

/** 调用 window.__recutTest 桥。 */
export async function testGet<T = any>(
	page: Page,
	method: string,
	...args: any[]
): Promise<T> {
	return page.evaluate(
		([name, rest]) => (window as any).__recutTest[name](...rest),
		[method, args],
	);
}

/** 等待一个交互后的渲染稳定。 */
export async function settle(page: Page): Promise<void> {
	await testGet(page, "advanceFrame");
	await page.waitForTimeout(80);
}

/** 当前画布显示缩放（canvas 像素 → 屏幕像素）。 */
export async function getDisplayScale(page: Page): Promise<number> {
	return page.evaluate(() => {
		const c = document.querySelector("canvas[data-recut-canvas]") as HTMLCanvasElement;
		return c.getBoundingClientRect().width / c.width;
	});
}
