import type { Browser, BrowserType, Page } from "@playwright/test";
import { chromium } from "@playwright/test";

/**
 * 统一浏览器启动：编辑器渲染 HTML-in-Canvas 组件（html/react surface 的 DOM→纹理
 * 捕获）依赖 Chromium 的 `CanvasDrawElement` 特性。不开启时捕获不到 DOM 内容，
 * 预览/封面/导出都会是纯黑画面。所有 e2e 调试与测试必须经此启动。
 */
export const CANVAS_DRAW_ELEMENT_FLAG = "--enable-features=CanvasDrawElement";

/** 启动带必需 flag 的 Chromium；headless 也适用。 */
export async function launchEditorBrowser(
	options: {
		headless?: boolean;
		args?: string[];
	} = {},
): Promise<Browser> {
	return chromium.launch({
		headless: options.headless ?? true,
		args: [
			"--use-gl=swiftshader",
			"--enable-unsafe-swiftshader",
			CANVAS_DRAW_ELEMENT_FLAG,
			...(options.args ?? []),
		],
	});
}

/** 断言当前浏览器已启用 CanvasDrawElement（captureElementImage 存在）。 */
export async function assertCanvasDrawElement(page: Page): Promise<void> {
	const enabled = await page.evaluate(
		() => typeof HTMLCanvasElement.prototype.captureElementImage === "function",
	);
	if (!enabled) {
		throw new Error(
			"CanvasDrawElement 未启用：编辑器 HTML-in-Canvas 组件渲染为黑屏。请用 launchEditorBrowser() 启动浏览器。",
		);
	}
}

export function closeTo(received: number, expected: number, tolerance = 2): boolean {
	return Math.abs(received - expected) <= tolerance;
}

export async function openDemo(page: Page): Promise<void> {
	await page.goto("/demo.html?test=1");
	await page.waitForSelector("canvas[data-recut-canvas]", { timeout: 15_000 });
	await page.waitForFunction(
		() => (window as any).__recutTest?.getNodeBounds("demo-el-glow") != null,
		{ timeout: 15_000 },
	);
	await testGet(page, "setTime", 0);
	await testGet(page, "advanceFrame");
}

/** 调用 window.__recutTest 桥。 */
export async function testGet<T = any>(
	page: Page,
	method: string,
	...args: any[]
): Promise<T> {
	return page.evaluate(
		([name, rest]) => (window as any).__recutTest[name](...rest),
		[method, args],
	);
}

/** 等待一个交互后的渲染稳定。 */
export async function settle(page: Page): Promise<void> {
	await testGet(page, "advanceFrame");
	await page.waitForTimeout(80);
}

/** 当前画布显示缩放（canvas 像素 → 屏幕像素）。 */
export async function getDisplayScale(page: Page): Promise<number> {
	return page.evaluate(() => {
		const c = document.querySelector("canvas[data-recut-canvas]") as HTMLCanvasElement;
		return c.getBoundingClientRect().width / c.width;
	});
}
