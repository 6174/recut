import { test, expect } from "@playwright/test";
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * AI 临时组件渲染链路 E2E：
 * fixture 源码 → component-build.js（esbuild+tsc+确定性扫描）→ bundle →
 * harness 页 setComponent(注入 bundle) → blob import + prelude 共享实例 →
 * ensureComponent 注册 → WorldScene 渲染 → 像素断言。
 * L1 html / L2 react 依赖 html-in-canvas（Chrome 149+ flag），不支持时仅断言"渲染无异常"。
 */
const SPEC_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(SPEC_DIR, "../../../");
const BUILD_SCRIPT = path.join(APP_ROOT, "scripts", "component-build.js");
const SDK_DIR = path.join(APP_ROOT, "sdk");
const FIXTURES = path.join(SPEC_DIR, "fixtures", "components");

const FIXTURES_META: Record<string, { surface: string; inputs: Array<{ key: string; default: unknown }> }> = {
	"countdown": { surface: "html", inputs: [{ key: "color", default: "#0ea5e9" }] },
	"pulse-card": {
		surface: "react",
		inputs: [
			{ key: "text", default: "Recut" },
			{ key: "color", default: "#0ea5e9" },
		],
	},
	"pulse-cube": { surface: "r3f", inputs: [{ key: "color", default: "#ff2244" }] },
};

function buildFixture(name: string): { bundle: string; bundleHash: string } {
	const sourcePath = path.join(FIXTURES, `${name}.tsx`);
	const outPath = path.join(os.tmpdir(), `recut-e2e-${name}.js`);
	const result = spawnSync("node", [BUILD_SCRIPT, sourcePath, outPath, SDK_DIR], {
		encoding: "utf8",
	});
	const parsed = JSON.parse(result.stdout || "{}");
	if (!parsed.ok) {
		throw new Error(`build ${name} 失败: ${JSON.stringify(parsed)}`);
	}
	return { bundle: fs.readFileSync(outPath, "utf8"), bundleHash: parsed.bundleHash };
}

const bundles: Record<string, { bundle: string; bundleHash: string }> = {};

test.beforeAll(() => {
	for (const name of Object.keys(FIXTURES_META)) {
		bundles[name] = buildFixture(name);
	}
});

test.beforeEach(async ({ page }) => {
	await page.goto("/component-harness.html");
});

for (const [name, meta] of Object.entries(FIXTURES_META)) {
	test(`渲染链路：${name}（${meta.surface}）`, async ({ page }) => {
		const htmlInCanvas = await page.evaluate(() => (window as any).__recutHarness.supported());
		const setOk = await page.evaluate(
			([componentId, surface, inputs, bundle, bundleHash]) =>
				(window as any).__recutHarness.setComponent({
					componentId,
					name: componentId,
					surface,
					inputs,
					bundle,
					bundleHash,
				}),
			[name, meta.surface, meta.inputs, bundles[name].bundle, bundles[name].bundleHash],
		);
		expect(setOk).toBe(true);

		const status = await page.evaluate(() => (window as any).__recutHarness.render(0.5, 5));
		expect(status.status).toBe("rendered");
		expect(status.surface).toBe(meta.surface);

		// 组件确实挂载了场景对象（非占位）
		const hasNode = await page.evaluate(() => (window as any).__recutHarness.hasNodeObject());
		expect(hasNode).toBe(true);

		if (meta.surface === "r3f") {
			// 中心像素 = 立方体色（红）；(380,180) 在 t=0（size 100→半 50）外、t=2.5（size 140→半 70）内 → 动画改变几何
			const pCenter = await page.evaluate(([x, y]) => (window as any).__recutHarness.readPixel(x, y), [320, 180]);
			expect(pCenter[0]).toBeGreaterThan(150);
			expect(pCenter[1]).toBeLessThan(120);
			const at0 = await page.evaluate(([x, y]) => (window as any).__recutHarness.readPixel(x, y), [380, 180]);
			await page.evaluate(() => (window as any).__recutHarness.render(2.5, 5));
			const at25 = await page.evaluate(([x, y]) => (window as any).__recutHarness.readPixel(x, y), [380, 180]);
			// 动画改变几何 → (380,180) 从背景变为立方体色
			expect(Math.abs(at0[0] - at25[0])).toBeGreaterThan(80);
		} else if (htmlInCanvas.htmlInCanvas) {
			// html/react 承载面：中心区域应出现非背景内容（capture 异步，轮询等待）
			await expect
				.poll(() =>
					page.evaluate(() => (window as any).__recutHarness.countNonBackground(280, 140, 80, 80)),
					{ timeout: 5000 },
				)
				.toBeGreaterThan(0);

			if (meta.surface === "react") {
				// 根节点铺满 512×512 承载面，但实际卡片只占中心的一小块：
				// 选择 bbox 必须来自可见纹理，不得回退为承载面或整幅画布。
				const bounds = await page.evaluate(
					() => (window as any).__recutHarness.getNodeBounds(),
				);
				expect(bounds.width).toBeLessThan(300);
				expect(bounds.height).toBeLessThan(120);
				expect(bounds.cx).toBeCloseTo(320, 0);
				// 动画会向上平移最多 10px，bbox 仍应围绕可见卡片而非承载面中心。
				expect(bounds.cy).toBeGreaterThan(165);
				expect(bounds.cy).toBeLessThan(180);
			}
		} else {
			test.info().annotations.push({
				type: "skip",
				description: "html-in-canvas 不可用（Chrome 149+ flag），仅断言渲染无异常",
			});
		}
	});
}
