import { test, expect } from "@playwright/test";
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * AI 组件素材面板 E2E：组件库 → AI 组件分类 → 卡片可点击 → 详情弹框（源码 + 真实渲染预览）。
 * 无宿主时经 window.__recutTest.aiComponents 测试注入点提供列表、源码与可加载 bundle。
 */
const SPEC_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(SPEC_DIR, "../../../");

const SAMPLE_SOURCE = `import { str } from "@recut/runtime";
import type { ComponentRenderContext } from "@recut/runtime";

export default {
  surface: "html",
  name: "Countdown",
  inputs: [{ key: "color", type: "color", default: "#0ea5e9", label: "主色" }],
  render(ctx: ComponentRenderContext) {
    const { params, progress, anim } = ctx;
    return \`<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#0ea5e9;font-size:80px;font-weight:800;">\${Math.ceil((1 - progress) * 5)}</div>\`;
  },
};
`;

let countdownBundle: { bundle: string; bundleHash: string };

test.beforeAll(() => {
	const sourcePath = path.join(
		SPEC_DIR,
		"fixtures",
		"components",
		"countdown.tsx",
	);
	const outPath = path.join(os.tmpdir(), "recut-e2e-panel-countdown.js");
	const result = spawnSync(
		"node",
		[
			path.join(APP_ROOT, "scripts", "component-build.js"),
			sourcePath,
			outPath,
			path.join(APP_ROOT, "sdk"),
		],
		{ encoding: "utf8" },
	);
	const parsed = JSON.parse(result.stdout || "{}");
	if (!parsed.ok) {
		throw new Error(`build countdown 失败: ${JSON.stringify(parsed)}`);
	}
	countdownBundle = { bundle: fs.readFileSync(outPath, "utf8"), bundleHash: parsed.bundleHash };
});

test.beforeEach(async ({ page }) => {
	await page.goto("/demo.html?test=1");
	await page.waitForSelector("canvas[data-recut-canvas]", { timeout: 15_000 });
	await page.waitForFunction(
		() => (window as any).__recutTest?.getNodeBounds("demo-el-glow") != null,
		{ timeout: 15_000 },
	);
	// demo 的 ?test=1 桥会重建 __recutTest，须在加载完成后注入 aiComponents 测试数据。
	await page.evaluate(
		({ source, bundle, bundleHash }) => {
			const current = (window as any).__recutTest ?? {};
			current.aiComponents = {
				list: [
					{
						componentId: "ai-countdown",
						name: "AI 倒计时卡片",
						surface: "html",
						keywords: ["countdown"],
						version: 2,
						status: "verified",
						inputs: [{ key: "color", type: "color", default: "#0ea5e9", label: "主色" }],
						testReport: { ok: true, checks: [{ name: "smoke", pass: true }] },
					},
					{
						componentId: "ai-broken",
						name: "AI 坏组件",
						surface: "r3f",
						keywords: ["broken"],
						version: 1,
						status: "failed",
						inputs: [],
						testReport: { ok: false, error: "render threw" },
					},
				],
				source: {
					"ai-countdown": source,
					"ai-broken":
						"export default { surface: 'r3f', name: 'Broken', inputs: [], render() { throw new Error('boom'); } };",
				},
				resolve: {
					"ai-countdown": {
						surface: "html",
						inputs: [{ key: "color", type: "color", default: "#0ea5e9", label: "主色" }],
						bundle,
						bundleHash,
					},
				},
			};
			(window as any).__recutTest = current;
		},
		{ source: SAMPLE_SOURCE, bundle: countdownBundle.bundle, bundleHash: countdownBundle.bundleHash },
	);
});

async function openAiComponentsCategory(page: import("@playwright/test").Page) {
	await page.getByRole("button", { name: "组件库" }).click();
	await page.getByRole("tab", { name: "AI 组件" }).click();
}

test("AI 组件出现在组件库并可点开详情（源码 + 预览）", async ({ page }) => {
	await openAiComponentsCategory(page);

	const card = page.getByRole("button", { name: /AI 倒计时卡片/ });
	await expect(card).toBeVisible();
	await expect(page.getByText("verified", { exact: true })).toBeVisible();
	await expect(page.getByText("failed", { exact: true })).toBeVisible();

	await card.click();

	const dialog = page.getByRole("dialog");
	await expect(dialog).toBeVisible();
	// 源码
	await expect(dialog.getByText(/Countdown/)).toBeVisible();
	await expect(dialog.getByText(/import \{ str \} from "@recut\/runtime"/)).toBeVisible();
	// 元信息
	await expect(dialog.getByText("ai-countdown", { exact: true })).toBeVisible();
	await expect(dialog.getByText("v2")).toBeVisible();

	// 预览：弹框应挂出预览 canvas 且无加载失败（html 承载面的像素级 capture 依赖
	// #canvas-draw-element 的异步纹理回传，headless 下不稳定；严格像素断言见 component-harness）。
	await expect.poll(() => dialog.locator("canvas").count(), { timeout: 8000 }).toBeGreaterThan(0);
	await expect(dialog.getByText(/加载失败/)).toHaveCount(0);
});

test("失败组件显示失败状态且可查看源码", async ({ page }) => {
	await openAiComponentsCategory(page);
	await page.getByRole("button", { name: /AI 坏组件/ }).click();
	const dialog = page.getByRole("dialog");
	await expect(dialog).toBeVisible();
	await expect(dialog.getByText("render threw")).toBeVisible();
	await expect(dialog.getByText(/throw new Error\('boom'\)/)).toBeVisible();
});
