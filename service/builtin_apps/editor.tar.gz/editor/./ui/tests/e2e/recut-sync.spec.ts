import { test, expect } from "@playwright/test";
import { openDemo, testGet, settle } from "./helpers";

/**
 * recut 项目实时同步（前端接收端）E2E：
 * useRecutProjectSync 订阅 recut.events；收到 project.document.changed（source:"agent"）
 * → 整份 reload；source:"ui"（自身保存回显）→ 忽略不 reload；project:locked → 只读（不保存）。
 * 通过 window.postMessage 注入 recut.project.event 模拟宿主转发。
 */
test.describe("recut project sync (frontend)", () => {
	test("agent document.changed 触发 reload，ui 回显被忽略", async ({ page }) => {
		await openDemo(page);

		const reloadsBefore = await testGet(page, "getReloadCount");
		const versionBefore = await testGet(page, "getProjectVersion");

		// 1) ui 回显（自身保存）：只更新 knownVersion，不 reload。
		await page.evaluate(
			(v) =>
				window.postMessage(
					{ type: "recut.project.event", event: { type: "project.document.changed", version: v, source: "ui" } },
					"*",
				),
			(versionBefore ?? 0) + 1,
		);
		await settle(page);
		expect(await testGet(page, "getReloadCount")).toBe(reloadsBefore);

		// 2) agent 外部变更：version 超过 known → reload。
		await page.evaluate(
			(v) =>
				window.postMessage(
					{ type: "recut.project.event", event: { type: "project.document.changed", version: v, source: "agent" } },
					"*",
				),
			(versionBefore ?? 0) + 50,
		);
		await settle(page);
		await page.waitForTimeout(400);
		expect(await testGet(page, "getReloadCount")).toBe(reloadsBefore + 1);

		// 3) 更低版本 agent 事件：不 reload（版本不前进）。
		await page.evaluate(() =>
			window.postMessage(
				{ type: "recut.project.event", event: { type: "project.document.changed", version: 0, source: "agent" } },
				"*",
			),
		);
		await settle(page);
		expect(await testGet(page, "getReloadCount")).toBe(reloadsBefore + 1);
	});

	test("project:locked 不触发 reload，project:unlocked 恢复并 reload", async ({ page }) => {
		await openDemo(page);
		const reloadsBefore = await testGet(page, "getReloadCount");

		await page.evaluate(() =>
			window.postMessage(
				{ type: "recut.project.event", event: { type: "project:locked", owner: "agent-e2e", version: 1 } },
				"*",
			),
		);
		await settle(page);
		expect(await testGet(page, "getReloadCount")).toBe(reloadsBefore);
		// 编辑器仍存活（画布未卸载）。
		expect(await page.locator("canvas[data-recut-canvas]").count()).toBe(1);

		// 解锁：恢复自动保存并同步一次（reload +1）。
		await page.evaluate(() =>
			window.postMessage(
				{ type: "recut.project.event", event: { type: "project:unlocked", version: 1 } },
				"*",
			),
		);
		await settle(page);
		await page.waitForTimeout(400);
		expect(await testGet(page, "getReloadCount")).toBe(reloadsBefore + 1);
	});
});
