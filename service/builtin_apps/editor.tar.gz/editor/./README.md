# recut-editor - Recut 时间线剪辑应用

React + TypeScript + Vite 的项目型 Recut App。它将素材、文字、效果与音频组织为时间线项目，并通过 `background.js` 持久化项目状态和导出成片。

<directory>
ui/ - 编辑器前端：时间线、预览画布、素材面板和导出界面
skills/ - 面向 Agent 的剪辑工作流与操作约束
scripts/ - 本地开发与导出辅助脚本
</directory>

<config>
manifest.json - App 身份、权限、运行时入口及平台操作契约
background.js - 项目数据、素材登记和导出操作的后端入口
ui/package.json - 前端依赖、开发和构建命令
</config>

开发时在 `ui/` 执行 `npm run dev`；发布前执行 `npm run build`，运行时消费 `ui/dist/index.html`。`node_modules/` 与 `ui/dist/` 均为本地生成物，不纳入版本控制。

[PROTOCOL]: 变更时更新此头部，然后检查 README.md
