# recut-editor - Recut 时间线剪辑应用

React + TypeScript + Vite 的项目型 Recut App。它将素材、文字、效果与音频组织为时间线项目，并通过 `background.js` 持久化项目状态和导出成片。

<directory>
ui/ - 编辑器前端：时间线、预览画布、素材面板和导出界面
skills/ - 面向 Agent 的剪辑工作流与操作约束
scripts/ - 本地开发与导出辅助脚本
</directory>

<config>
manifest.json - App 身份、权限、运行时入口及平台操作契约
background.js - 项目数据、素材登记和导出操作的后端入口
ui/package.json - 前端依赖、开发和构建命令
</config>

开发时在 `ui/` 执行 `npm run dev`；发布前执行 `npm run build`，运行时消费 `ui/dist/index.html`。`node_modules/` 与 `ui/dist/` 均为本地生成物，不纳入版本控制。

## 渲染前提：CanvasDrawElement（必需）

编辑器用原生 HTML-in-Canvas 把 html/react surface 组件（DOM→纹理捕获）与文字渲染进 WebGL 画布，
依赖 Chromium 的 `CanvasDrawElement` 特性（Chrome 149+）。**不开启时组件/文字渲染为纯黑**，
预览、封面、导出全部黑屏；封面还会被显式跳过（返回 null，绝不推黑帧）。

- 浏览器：`chrome://flags/#canvas-draw-element` 设为 Enabled，或启动参数 `--enable-features=CanvasDrawElement`。
- Playwright 测试：`ui/playwright.config.ts` 已带该 flag；**手动 `chromium.launch()` 调试必须复用
  `tests/e2e/helpers.ts` 的 `launchEditorBrowser()`**（内部带 flag），并可用 `assertCanvasDrawElement(page)` 校验。
- 封面时序：首帧封面复用预览的常驻 renderer 输出（seek 到 t=0 抓 `canvas[data-recut-canvas]`），
  与用户看到的内容一致；预览 canvas 不可达时才回退到独立离屏渲染。

[PROTOCOL]: 变更时更新此头部，然后检查 README.md
