/**
 * [INPUT]: manifest 声明的 operations（api+mcp 双 surface），ctx.sqlite/files/media/shell/project
 * [OUTPUT]: 剪辑项目 TProject 的持久化与读取、时间线素材登记、成片导入素材库并设封面
 * [POS]: recut.editor 的业务后端；编辑器 UI 在 iframe 内以 recut-sdk 调用 api 操作，
 *        Agent 以 recut.editor.* MCP 工具调用 mcp 操作。素材只交换 assetId。
 * [PROTOCOL]: 变更时更新此头部，然后检查 README.md
 */

const DEFAULT_FPS = { numerator: 30, denominator: 1 };
const DEFAULT_CANVAS = { width: 1920, height: 1080 };
const TICKS_PER_SECOND = 120000;

function scope(ctx) {
  return ctx.project ? ctx.project.id : "";
}

function ensureSchema(ctx, scopeId) {
  ctx.sqlite.execute(
    "create table if not exists editor_projects (" +
      "project_id text not null primary key, " +
      "project_json text not null, " +
      "registered_assets_json text not null default '[]', " +
      "version integer not null default 1, " +
      "updated_at text not null)",
    [scopeId],
  );
}

function nowIso() {
  return new Date().toISOString();
}

function makeDefaultProject({ scopeId, name, settings, materialAssetIds }) {
  const now = nowIso();
  const mainTrackId = `track-main-${Math.random().toString(36).slice(2, 10)}`;
  const sceneId = `scene-${Math.random().toString(36).slice(2, 10)}`;
  const fps = settings?.fps || DEFAULT_FPS;
  const canvasSize = settings?.canvasSize || DEFAULT_CANVAS;
  const background = settings?.background || { type: "color", color: "#000000" };
  const projectId = scopeId;
  return {
    metadata: {
      id: projectId,
      name: name || "未命名剪辑",
      thumbnail: null,
      duration: 0,
      createdAt: now,
      updatedAt: now,
    },
    scenes: [
      {
        id: sceneId,
        name: "Main scene",
        isMain: true,
        tracks: {
          overlay: [],
          main: {
            id: mainTrackId,
            name: "Main",
            type: "video",
            elements: [],
            muted: false,
            hidden: false,
          },
          audio: [],
        },
        bookmarks: [],
        createdAt: now,
        updatedAt: now,
      },
    ],
    currentSceneId: sceneId,
    settings: { fps, canvasSize, background },
    version: 1,
    materialAssetIds: materialAssetIds || [],
  };
}

function readProject(ctx, scopeId) {
  ensureSchema(ctx, scopeId);
  const rows = ctx.sqlite.query(
    "select project_json, registered_assets_json, version, updated_at from editor_projects where project_id = ?",
    [scopeId],
  );
  if (!rows || rows.length === 0) {
    return null;
  }
  const row = rows[0];
  let project = null;
  try {
    project = JSON.parse(row.project_json);
  } catch (e) {
    project = null;
  }
  return {
    project,
    registeredAssets: JSON.parse(row.registered_assets_json || "[]"),
    version: row.version,
    updatedAt: row.updated_at,
  };
}

function writeProject(ctx, scopeId, project, registeredAssets, version) {
  ensureSchema(ctx, scopeId);
  const existing = readProject(ctx, scopeId);
  const nextVersion = (existing?.version || 0) + 1;
  const nextRegistered = registeredAssets ?? existing?.registeredAssets ?? [];
  const projectWithVersion = project
    ? { ...project, version: nextVersion }
    : project;
  ctx.sqlite.execute(
    "insert into editor_projects (project_id, project_json, registered_assets_json, version, updated_at) values (?, ?, ?, ?, ?) " +
      "on conflict(project_id) do update set " +
      "project_json = excluded.project_json, registered_assets_json = excluded.registered_assets_json, " +
      "version = excluded.version, updated_at = excluded.updated_at",
    [
      scopeId,
      JSON.stringify(projectWithVersion),
      JSON.stringify(nextRegistered),
      nextVersion,
      nowIso(),
    ],
  );
  return nextVersion;
}

function collectTimelineAssetIds(project) {
  const ids = new Set(project?.materialAssetIds || []);
  for (const scene of project?.scenes || []) {
    for (const track of [
      ...(scene.tracks?.overlay || []),
      scene.tracks?.main,
      ...(scene.tracks?.audio || []),
    ]) {
      if (!track || !track.elements) continue;
      for (const element of track.elements) {
        if (element.mediaId) ids.add(element.mediaId);
        if (element.sourceUrl) ids.add(element.sourceUrl);
      }
    }
  }
  return Array.from(ids);
}

function summarizeTimeline(project) {
  let elements = 0;
  let tracks = 0;
  for (const scene of project?.scenes || []) {
    for (const track of [
      ...(scene.tracks?.overlay || []),
      scene.tracks?.main,
      ...(scene.tracks?.audio || []),
    ]) {
      if (!track) continue;
      tracks += 1;
      elements += track.elements?.length || 0;
    }
  }
  return { elements, tracks };
}

function projectDurationTicks(project) {
  let maxEnd = 0;
  for (const scene of project?.scenes || []) {
    for (const track of [
      ...(scene.tracks?.overlay || []),
      scene.tracks?.main,
      ...(scene.tracks?.audio || []),
    ]) {
      if (!track || !track.elements) continue;
      for (const element of track.elements) {
        const end = (element.startTime || 0) + (element.duration || 0);
        if (end > maxEnd) maxEnd = end;
      }
    }
  }
  return maxEnd;
}

recut.operation.register("project.create", (input, ctx) => {
  const scopeId = scope(ctx);
  const now = nowIso();
  const project = makeDefaultProject({
    scopeId,
    name: input?.name,
    settings: input?.settings,
    materialAssetIds: input?.materialAssetIds,
  });
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "insert into editor_projects (project_id, project_json, registered_assets_json, version, updated_at) values (?, ?, ?, ?, ?) " +
      "on conflict(project_id) do update set " +
      "project_json = excluded.project_json, registered_assets_json = excluded.registered_assets_json, " +
      "version = excluded.version, updated_at = excluded.updated_at",
    [scopeId, JSON.stringify(project), JSON.stringify(input?.materialAssetIds || []), 1, now],
  );
  return { projectId: scopeId, project };
});

recut.operation.register("project.load", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  if (!existing?.project) {
    const project = makeDefaultProject({ scopeId, name: undefined });
    writeProject(ctx, scopeId, project, [], 1);
    return { project, registeredAssets: [], version: 1 };
  }
  return {
    project: existing.project,
    registeredAssets: existing.registeredAssets,
    version: existing.version,
  };
});

recut.operation.register("project.save", (input, ctx) => {
  const scopeId = scope(ctx);
  if (!input?.project) {
    throw new Error("project.save: missing project");
  }
  const nextVersion = writeProject(ctx, scopeId, input.project, undefined, input.version);
  return { ok: true, version: nextVersion, savedAt: nowIso() };
});

recut.operation.register("workflow.context", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  const project = existing?.project;
  const timeline = summarizeTimeline(project);
  const durationTicks = projectDurationTicks(project);
  const hasElements = timeline.elements > 0;
  return {
    projectId: scopeId,
    stage: hasElements ? "editing" : "brief",
    settings: project?.settings || null,
    timeline,
    durationSeconds: durationTicks / TICKS_PER_SECOND,
    registeredAssets: existing?.registeredAssets || [],
    nextAction: hasElements ? "edit_timeline" : "create_project",
    allowedActions: hasElements
      ? ["timeline.assets", "export.start", "export.complete", "film.package.import"]
      : ["project.create", "film.package.import"],
    paths: {
      appRoot: ctx.paths?.appRoot || null,
      projectFilesRoot: ctx.paths?.projectFilesRoot || null,
    },
  };
});

recut.operation.register("timeline.assets", (input, ctx) => {
  const scopeId = scope(ctx);
  if (!Array.isArray(input?.assetIds)) {
    throw new Error("timeline.assets: assetIds array required");
  }
  const unique = Array.from(new Set(input.assetIds));
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "update editor_projects set registered_assets_json = ?, updated_at = ? where project_id = ?",
    [JSON.stringify(unique), nowIso(), scopeId],
  );
  return { registered: unique.length, assetIds: unique };
});

recut.operation.register("export.start", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  const exportId = `export-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "create table if not exists editor_exports (" +
      "export_id text not null primary key, project_id text not null, settings_json text not null, " +
      "asset_id text, status text not null, created_at text not null, updated_at text not null)",
  );
  ctx.sqlite.execute(
    "insert into editor_exports (export_id, project_id, settings_json, status, created_at, updated_at) values (?, ?, ?, 'encoding', ?, ?)",
    [
      exportId,
      scopeId,
      JSON.stringify({
        width: input?.width || existing?.project?.settings?.canvasSize?.width || 1920,
        height: input?.height || existing?.project?.settings?.canvasSize?.height || 1080,
        fps: input?.fps || 30,
      }),
      nowIso(),
      nowIso(),
    ],
  );
  return { exportId };
});

recut.operation.register("export.progress", (input, ctx) => {
  if (!input?.exportId || typeof input?.progress !== "number") {
    throw new Error("export.progress: exportId + progress required");
  }
  return { exportId: input.exportId, progress: Math.max(0, Math.min(1, input.progress)) };
});

recut.operation.register("export.complete", (input, ctx) => {
  const scopeId = scope(ctx);
  if (!input?.exportId || !input?.fileBase64) {
    throw new Error("export.complete: exportId + fileBase64 required");
  }
  const b64Path = `exports/${input.exportId}.b64`;
  const mp4Path = `exports/${input.exportId}.mp4`;
  ctx.files.writeText(b64Path, input.fileBase64);
  const scriptPath = `${ctx.paths.appRoot}/scripts/decode-base64.js`;
  ctx.shell.exec({
    command: "node",
    args: [scriptPath, b64Path, mp4Path],
    cwd: "files",
    timeoutSeconds: 300,
  });
  const name = input.name || `成片 ${input.exportId}`;
  const asset = ctx.media.importFile({
    path: mp4Path,
    name,
    mimeType: input.mimeType || "video/mp4",
  });
  if (asset && asset.id) {
    ctx.project.setCover({ assetId: asset.id });
  }
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "update editor_exports set asset_id = ?, status = 'completed', updated_at = ? where export_id = ?",
    [asset?.id || null, nowIso(), input.exportId],
  );
  return { exportId: input.exportId, assetId: asset?.id || null };
});

recut.operation.register("export.list", (input, ctx) => {
  const scopeId = scope(ctx);
  ensureSchema(ctx, scopeId);
  const rows = ctx.sqlite.query(
    "select export_id, settings_json, asset_id, status, created_at from editor_exports where project_id = ? order by created_at desc",
    [scopeId],
  );
  return { exports: rows || [] };
});

recut.operation.register("film.package.import", (input, ctx) => {
  const scopeId = scope(ctx);
  const pkg = input?.pkg || input;
  if (!pkg) {
    throw new Error("film.package.import: pkg required");
  }
  const existing = readProject(ctx, scopeId);
  const baseProject = existing?.project || makeDefaultProject({ scopeId, name: "AI 短片草稿" });
  const project = JSON.parse(JSON.stringify(baseProject));
  const now = nowIso();
  const scene = project.scenes.find((s) => s.isMain) || project.scenes[0];
  const mainTrack = scene.tracks.main;
  const tick = (sec) => Math.round((sec || 0) * TICKS_PER_SECOND);

  const addElement = (track, element) => {
    if (!track || !track.elements) {
      throw new Error(
        "addElement: track has no elements array: " + JSON.stringify({ trackName: track && track.name, hasElements: !!(track && track.elements) }),
      );
    }
    track.elements.push(element);
  };

  const mediaByScene = [];
  const scenes = pkg.scenes || [];
  const script = pkg.script || { beats: [] };

  const ensureTextTrack = () => {
    let track = scene.tracks.overlay.find((t) => t.type === "text");
    if (!track) {
      track = {
        id: `track-text-${Math.random().toString(36).slice(2, 10)}`,
        name: "Text",
        type: "text",
        elements: [],
        hidden: false,
      };
      scene.tracks.overlay.push(track);
    }
    return track;
  };
  const ensureAudioTrack = () => {
    let track = scene.tracks.audio.find((t) => t.type === "audio");
    if (!track) {
      track = {
        id: `track-audio-${Math.random().toString(36).slice(2, 10)}`,
        name: "Audio",
        type: "audio",
        elements: [],
        muted: false,
      };
      scene.tracks.audio.push(track);
    }
    return track;
  };

  let cursor = 0;
  const beats = script.beats || (typeof script === "string" ? [] : []);
  for (let i = 0; i < scenes.length; i++) {
    const sc = scenes[i];
    const assetIds = sc.assetIds || sc.imageAssetIds || [];
    const durationSec = sc.durationSeconds || sc.durationSec || 5;
    const startTicks = tick(cursor);

    for (const assetId of assetIds) {
      addElement(mainTrack, {
        id: `el-${i}-${assetId.slice(-8)}`,
        name: sc.title || `镜头 ${i + 1}`,
        type: "video",
        mediaId: assetId,
        startTime: startTicks,
        duration: tick(durationSec),
        trimStart: 0,
        trimEnd: tick(durationSec),
        params: { "transform.positionX": 0, "transform.positionY": 0, "transform.scaleX": 1, "transform.scaleY": 1, "transform.rotate": 0, opacity: 1 },
        hidden: false,
      });
    }

    if (sc.title && sc.title !== `镜头 ${i + 1}`) {
      addElement(ensureTextTrack(), {
        id: `el-text-${i}`,
        name: sc.title,
        type: "text",
        startTime: startTicks,
        duration: tick(durationSec),
        trimStart: 0,
        trimEnd: tick(durationSec),
        params: {
          text: sc.title,
          fontSize: 72,
          fontFamily: "sans-serif",
          fillColor: "#FFFFFF",
          "transform.positionX": 0,
          "transform.positionY": -200,
          "transform.scaleX": 1,
          "transform.scaleY": 1,
          "transform.rotate": 0,
          opacity: 1,
          textAlign: "center",
        },
        hidden: false,
      });
    }
    cursor += durationSec;
  }

  if (pkg.audio?.voiceoverAssetId) {
    addElement(ensureAudioTrack(), {
      id: `el-vo-${Date.now().toString(36)}`,
      name: "配音",
      type: "audio",
      sourceType: "upload",
      mediaId: pkg.audio.voiceoverAssetId,
      startTime: 0,
      duration: tick(pkg.audio.durationSeconds || cursor || 10),
      trimStart: 0,
      trimEnd: tick(pkg.audio.durationSeconds || cursor || 10),
      params: { volume: 1 },
    });
  }

  project.metadata.updatedAt = now;
  scene.updatedAt = now;
  writeProject(ctx, scopeId, project, undefined, undefined);
  return { ok: true, elements: summarizeTimeline(project) };
});
