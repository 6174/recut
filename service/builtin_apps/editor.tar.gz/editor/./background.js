/**
 * [INPUT]: manifest 声明的 operations（api+mcp 双 surface），ctx.sqlite/files/media/shell/project。
 *          本文件内联 AI Model Core（纯 JS、goja-safe、无外部依赖）：TProject 形状 doc 上的
 *          op 引擎、timeline.validate 不变式、condensed 读取——UI 与 AI 共用同一数据形状。
 * [OUTPUT]: 剪辑项目 TProject 的持久化与读取、统一 op 日志（editor_command_log，snapshot undo 单一权威）、
 *          版本乐观锁 + aiLock 会话锁、时间线素材登记、headless 成片导入素材库并设封面。
 * [POS]: recut.editor 的业务后端；编辑器 UI 在 iframe 内以 recut-sdk 调用 api 操作，
 *        Agent 以 recut.editor.* MCP 工具调用 mcp 操作。素材只交换 assetId。
 *        变更由 AI Model Core 的 applyOp 统一落日志（可 undo），而非整份 JSON 覆盖。
 * [PROTOCOL]: 变更时更新此头部，然后检查 README.md
 */

// ============================================================================
// AI Model Core —— 纯函数，无 DOM/React 依赖，goja 可直接运行。
// 以 Node vm 测试时用 recut 桩加载本文件即可访问顶层函数。
// ============================================================================
var TICKS_PER_SECOND = 120000;
var DEFAULT_FPS = { numerator: 30, denominator: 1 };
var DEFAULT_CANVAS = { width: 1920, height: 1080 };
var DEFAULT_BLEND_MODES = [
  "normal", "multiply", "screen", "overlay", "darken", "lighten",
  "color-dodge", "color-burn", "hard-light", "soft-light", "difference",
  "exclusion", "hue", "saturation", "color", "luminosity", "additive",
];

function tickOf(sec) {
  return Math.round((typeof sec === "number" ? sec : 0) * TICKS_PER_SECOND);
}
function secOf(ticks) {
  return (ticks || 0) / TICKS_PER_SECOND;
}
function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

var CORE_DEFAULT_PARAMS = {
  "transform.positionX": 0,
  "transform.positionY": 0,
  "transform.positionZ": 0,
  "transform.scaleX": 1,
  "transform.scaleY": 1,
  "transform.rotate": 0,
  opacity: 1,
  blendMode: "normal",
};
var CORE_DEFAULT_TEXT_PARAMS = {
  content: "文本",
  fontFamily: "sans-serif",
  fontSize: 72,
  color: "#FFFFFF",
  textAlign: "center",
  fontWeight: "400",
  fontStyle: "normal",
  textDecoration: "none",
  letterSpacing: 0,
  lineHeight: 1.2,
};
var CORE_DEFAULT_AUDIO_PARAMS = { volume: 1, muted: false };

function coreParamsForType(type) {
  var p = Object.assign({}, CORE_DEFAULT_PARAMS);
  if (type === "text") Object.assign(p, CORE_DEFAULT_TEXT_PARAMS);
  if (type === "audio") Object.assign(p, CORE_DEFAULT_AUDIO_PARAMS);
  return p;
}

function makeTrack(type, seq, name) {
  var suffix = "-" + (seq === undefined || seq === null ? Math.random().toString(36).slice(2, 8) : "ai" + seq);
  return {
    id: "track-" + type + suffix,
    name: name || trackDefaultName(type),
    type: type,
    elements: [],
    muted: false,
    hidden: false,
  };
}
function trackDefaultName(type) {
  var names = { video: "Main", text: "Text", audio: "Audio", graphic: "Graphic", effect: "Effect" };
  return names[type] || "Track";
}

function findScene(project, sceneId) {
  if (!project || !Array.isArray(project.scenes)) return null;
  if (sceneId) {
    var found = null;
    for (var i = 0; i < project.scenes.length; i++) {
      if (project.scenes[i].id === sceneId) { found = project.scenes[i]; break; }
    }
    if (found) return found;
  }
  for (var j = 0; j < project.scenes.length; j++) {
    if (project.scenes[j].isMain) return project.scenes[j];
  }
  return project.scenes[0] || null;
}

function sceneTracks(scene) {
  if (!scene.tracks) {
    scene.tracks = { overlay: [], main: null, audio: [] };
  }
  if (!scene.tracks.main) {
    scene.tracks.main = makeTrack("video", null, "Main");
    scene.tracks.main.type = "video";
  }
  if (!scene.tracks.overlay) scene.tracks.overlay = [];
  if (!scene.tracks.audio) scene.tracks.audio = [];
  return scene.tracks;
}

function findTrack(scene, trackId) {
  var t = sceneTracks(scene);
  if (t.main && t.main.id === trackId) return t.main;
  var list = (t.overlay || []).concat(t.audio || []);
  for (var i = 0; i < list.length; i++) {
    if (list[i].id === trackId) return list[i];
  }
  return null;
}

function defaultTrackTypeForElement(type) {
  if (type === "video" || type === "image") return "video";
  if (type === "text") return "text";
  if (type === "audio") return "audio";
  if (type === "graphic" || type === "component") return "graphic";
  if (type === "effect") return "effect";
  return "video";
}

function findOrCreateTrack(scene, trackType, seq, trackId) {
  var t = sceneTracks(scene);
  if (trackId) {
    var existing = findTrack(scene, trackId);
    if (existing) return existing;
  }
  if (trackType === "video") {
    if (t.main && t.main.elements && t.main.type === "video") return t.main;
    var main = t.main || makeTrack("video", seq, "Main");
    t.main = main;
    return main;
  }
  var arr = trackType === "audio" ? t.audio : t.overlay;
  for (var i = 0; i < arr.length; i++) {
    if (arr[i].type === trackType) return arr[i];
  }
  var track = makeTrack(trackType, seq, undefined);
  arr.push(track);
  return track;
}

function addTrackToScene(scene, type, seq, name, index) {
  var t = sceneTracks(scene);
  if (type === "video") {
    var existingMain = t.main;
    if (existingMain && existingMain.elements && existingMain.elements.length === 0 && (!name || existingMain.name === "Main")) {
      if (name) existingMain.name = name;
      return existingMain;
    }
    var track = makeTrack("video", seq, name || "Video " + (t.overlay.length + 1));
    track.type = "video";
    if (typeof index === "number") t.overlay.splice(index, 0, track);
    else t.overlay.push(track);
    return track;
  }
  var arr = type === "audio" ? t.audio : t.overlay;
  var track = makeTrack(type, seq, name);
  if (typeof index === "number") arr.splice(index, 0, track);
  else arr.push(track);
  return track;
}

function removeTrackFromScene(scene, trackId) {
  var t = sceneTracks(scene);
  if (t.main && t.main.id === trackId) {
    if (t.main.elements.length > 0) return false;
    return true; // main track 不可删除；返回 true 表示忽略
  }
  var arr = t.overlay.concat(t.audio);
  var removed = false;
  for (var i = 0; i < t.overlay.length; i++) {
    if (t.overlay[i].id === trackId) {
      if (t.overlay[i].elements.length > 0) return false;
      t.overlay.splice(i, 1);
      removed = true;
      break;
    }
  }
  if (!removed) {
    for (var j = 0; j < t.audio.length; j++) {
      if (t.audio[j].id === trackId) {
        if (t.audio[j].elements.length > 0) return false;
        t.audio.splice(j, 1);
        removed = true;
        break;
      }
    }
  }
  return removed;
}

function buildElement(payload, seq) {
  var type = payload.type;
  var el = {
    id: payload.elementId || "el-ai" + seq + "-" + (payload.slot || 0),
    name: payload.name || defaultElementName(type),
    type: type,
    startTime: tickOf(payload.startSec),
    duration: Math.max(tickOf(payload.durationSec), 1),
    trimStart: tickOf(payload.trimStartSec),
    trimEnd: tickOf(payload.trimEndSec),
    params: Object.assign({}, coreParamsForType(type), payload.params || {}),
  };
  if (type === "video" || type === "image") {
    el.mediaId = payload.mediaId;
  } else if (type === "text") {
    if (typeof payload.content === "string") el.params.content = payload.content;
  } else if (type === "graphic") {
    el.definitionId = payload.definitionId || "rectangle";
  } else if (type === "component") {
    el.componentId = payload.componentId;
  } else if (type === "effect") {
    el.effectType = payload.effectType;
  } else if (type === "audio") {
    if (payload.sourceType === "library") {
      el.sourceType = "library";
      el.sourceUrl = payload.sourceUrl;
    } else {
      el.sourceType = "upload";
      el.mediaId = payload.mediaId;
    }
  }
  if (payload.trimEndSec === undefined || payload.trimEndSec === null) {
    el.trimEnd = el.duration;
  }
  el.hidden = !!payload.hidden;
  return el;
}
function defaultElementName(type) {
  var names = { video: "视频", image: "图片", text: "文本", graphic: "图形", component: "组件", audio: "音频", effect: "特效" };
  return names[type] || type;
}

function upsertScalarKeyframe(element, path, atTicks, value, segmentToNext) {
  if (!element.animations) element.animations = {};
  var channel = element.animations[path];
  if (!channel || !channel.keys || !channel.keys.length) {
    element.animations[path] = {
      keys: [{ value: value, time: atTicks, segmentToNext: segmentToNext || "linear", leftHandle: null, rightHandle: null, tangentMode: "auto" }],
    };
    return;
  }
  var keys = channel.keys;
  var found = null;
  for (var i = 0; i < keys.length; i++) {
    if (keys[i].time === atTicks) { found = keys[i]; break; }
  }
  if (found) {
    found.value = value;
  } else {
    keys.push({ value: value, time: atTicks, segmentToNext: segmentToNext || "linear", leftHandle: null, rightHandle: null, tangentMode: "auto" });
    keys.sort(function (a, b) { return a.time - b.time; });
  }
}

function setParamAt(element, path, value, atSec) {
  var atTicks = atSec === undefined || atSec === null ? null : tickOf(atSec);
  var channel = element.animations && element.animations[path];
  var hasKeyframes = channel && channel.keys && channel.keys.length > 0;
  if (hasKeyframes && atTicks !== null) {
    upsertScalarKeyframe(element, path, atTicks, value, "linear");
  } else {
    element.params[path] = value;
  }
}

function elementRefPath(ref) {
  return { trackId: ref && ref.trackId, elementId: ref && ref.elementId };
}

function findElementInTrack(track, elementId) {
  if (!track || !track.elements) return null;
  for (var i = 0; i < track.elements.length; i++) {
    if (track.elements[i].id === elementId) return track.elements[i];
  }
  return null;
}

function removeElementFromTrack(track, elementId) {
  if (!track || !track.elements) return false;
  var idx = -1;
  for (var i = 0; i < track.elements.length; i++) {
    if (track.elements[i].id === elementId) { idx = i; break; }
  }
  if (idx < 0) return false;
  track.elements.splice(idx, 1);
  return true;
}

function rippleTrack(track, afterTimeTicks, deltaTicks) {
  if (!track || !track.elements || !deltaTicks) return;
  for (var i = 0; i < track.elements.length; i++) {
    var el = track.elements[i];
    if (el.startTime >= afterTimeTicks) {
      el.startTime = Math.max(0, el.startTime + deltaTicks);
    }
  }
}

// ---- op 引擎 -------------------------------------------------------------
function applyOp(project, op, opts) {
  opts = opts || {};
  var seq = opts.seq || 0;
  var payload = (op && op.payload) || {};
  var result = { refs: [] };
  var scene = findScene(project, payload.sceneId);

  switch (op.type) {
    case "insert": {
      var trackType = payload.trackType || defaultTrackTypeForElement(payload.element && payload.element.type);
      var track = findOrCreateTrack(scene, trackType, seq, payload.trackId);
      payload.element = payload.element || {};
      payload.element.elementId = payload.element.elementId || "el-ai" + seq + "-" + (payload.element.slot || 0);
      var el = buildElement(payload.element, seq);
      var idx = typeof payload.index === "number" ? payload.index : track.elements.length;
      track.elements.splice(idx, 0, el);
      result.refs.push({ trackId: track.id, elementId: el.id });
      result.element = { trackId: track.id, elementId: el.id, id: el.id };
      break;
    }
    case "delete": {
      var refs = payload.refs || [];
      var sceneRef = scene;
      var any = false;
      for (var d = 0; d < refs.length; d++) {
        var delTrack = findTrack(sceneRef, refs[d].trackId);
        if (delTrack && removeElementFromTrack(delTrack, refs[d].elementId)) any = true;
      }
      if (!any) throw new Error("delete: element not found");
      result.deleted = refs;
      break;
    }
    case "param": {
      var pEl = findElementInTrack(findTrack(scene, payload.ref && payload.ref.trackId), payload.ref && payload.ref.elementId);
      if (!pEl) throw new Error("param: element not found");
      var patch = payload.params || {};
      for (var pk in patch) {
        if (Object.prototype.hasOwnProperty.call(patch, pk)) {
          setParamAt(pEl, pk, patch[pk], payload.atSec);
        }
      }
      if (payload.fields) {
        for (var fk in payload.fields) {
          if (Object.prototype.hasOwnProperty.call(payload.fields, fk)) pEl[fk] = payload.fields[fk];
        }
      }
      result.refs.push(elementRefPath(payload.ref));
      break;
    }
    case "trim": {
      var trTrack = findTrack(scene, payload.ref && payload.ref.trackId);
      var trEl = trTrack && findElementInTrack(trTrack, payload.ref && payload.ref.elementId);
      if (!trEl) throw new Error("trim: element not found");
      var oldStart = trEl.startTime;
      var oldEnd = oldStart + trEl.duration;
      var newStart = payload.startSec !== undefined ? tickOf(payload.startSec) : trEl.startTime;
      if (payload.durationSec !== undefined) trEl.duration = Math.max(tickOf(payload.durationSec), 1);
      if (payload.trimStartSec !== undefined) trEl.trimStart = Math.max(tickOf(payload.trimStartSec), 0);
      if (payload.trimEndSec !== undefined) trEl.trimEnd = Math.max(tickOf(payload.trimEndSec), trEl.trimStart);
      trEl.startTime = Math.max(newStart, 0);
      if (payload.ripple) {
        var delta = trEl.startTime + trEl.duration - oldEnd;
        rippleTrack(trTrack, oldEnd, delta);
      }
      result.refs.push(elementRefPath(payload.ref));
      break;
    }
    case "split": {
      var spTrack = findTrack(scene, payload.ref && payload.ref.trackId);
      var spEl = spTrack && findElementInTrack(spTrack, payload.ref && payload.ref.elementId);
      if (!spEl) throw new Error("split: element not found");
      var localTicks = tickOf(payload.atSec) - spEl.startTime;
      if (localTicks <= 0 || localTicks >= spEl.duration) throw new Error("split: atSec outside element");
      var retainSide = payload.retainSide || "both";
      var sourceStart = spEl.trimStart;
      var sourceEnd = spEl.trimEnd === undefined || spEl.trimEnd === null ? spEl.trimStart + spEl.duration : spEl.trimEnd;
      var sourceSpan = sourceEnd - sourceStart;
      var leftDur = localTicks;
      var rightDur = spEl.duration - localTicks;
      payload.leftElementId = payload.leftElementId || "el-ai" + seq + "-r1";
      payload.rightElementId = payload.rightElementId || "el-ai" + seq + "-r2";
      var leftClone = cloneJson(spEl);
      var rightClone = cloneJson(spEl);
      leftClone.id = payload.leftElementId;
      rightClone.id = payload.rightElementId;
      leftClone.duration = leftDur;
      leftClone.trimEnd = sourceStart + Math.round((sourceSpan * leftDur) / spEl.duration);
      rightClone.startTime = spEl.startTime + localTicks;
      rightClone.duration = rightDur;
      rightClone.trimStart = sourceStart + Math.round((sourceSpan * leftDur) / spEl.duration);
      var elIdx = -1;
      for (var s = 0; s < spTrack.elements.length; s++) {
        if (spTrack.elements[s].id === spEl.id) { elIdx = s; break; }
      }
      spTrack.elements.splice(elIdx, 1);
      var insertAt = elIdx;
      var keepLeft = retainSide === "left" || retainSide === "both";
      var keepRight = retainSide === "right" || retainSide === "both";
      if (keepLeft) spTrack.elements.splice(insertAt++, 0, leftClone);
      if (keepRight) spTrack.elements.splice(insertAt, 0, rightClone);
      if (keepLeft) result.refs.push({ trackId: spTrack.id, elementId: leftClone.id });
      if (keepRight) result.refs.push({ trackId: spTrack.id, elementId: rightClone.id });
      break;
    }
    case "keyframe-upsert": {
      var kfTrack = findTrack(scene, payload.ref && payload.ref.trackId);
      var kfEl = kfTrack && findElementInTrack(kfTrack, payload.ref && payload.ref.elementId);
      if (!kfEl) throw new Error("keyframe-upsert: element not found");
      upsertScalarKeyframe(kfEl, payload.path, tickOf(payload.atSec), payload.value, payload.segmentToNext);
      result.refs.push(elementRefPath(payload.ref));
      break;
    }
    case "keyframe-remove": {
      var krTrack = findTrack(scene, payload.ref && payload.ref.trackId);
      var krEl = krTrack && findElementInTrack(krTrack, payload.ref && payload.ref.elementId);
      if (!krEl) throw new Error("keyframe-remove: element not found");
      if (krEl.animations && krEl.animations[payload.path]) {
        if (payload.atSec === undefined || payload.atSec === null) {
          delete krEl.animations[payload.path];
        } else {
          var at = tickOf(payload.atSec);
          var keys = krEl.animations[payload.path].keys || [];
          krEl.animations[payload.path].keys = keys.filter(function (k) { return k.time !== at; });
          if (krEl.animations[payload.path].keys.length === 0) delete krEl.animations[payload.path];
        }
      }
      result.refs.push(elementRefPath(payload.ref));
      break;
    }
    case "track-add": {
      var newTrack = addTrackToScene(scene, payload.type, seq, payload.name, payload.index);
      result.refs.push({ trackId: newTrack.id, elementId: null });
      result.trackId = newTrack.id;
      break;
    }
    case "track-remove": {
      var ok = removeTrackFromScene(scene, payload.trackId);
      if (ok === false) throw new Error("track-remove: track not empty or missing");
      break;
    }
    case "track-mute": {
      var mTrack = findTrack(scene, payload.trackId);
      if (!mTrack) throw new Error("track-mute: track not found");
      mTrack.muted = payload.muted !== undefined ? !!payload.muted : !mTrack.muted;
      break;
    }
    case "track-visible": {
      var vTrack = findTrack(scene, payload.trackId);
      if (!vTrack) throw new Error("track-visible: track not found");
      vTrack.hidden = payload.hidden !== undefined ? !!payload.hidden : !vTrack.hidden;
      break;
    }
    case "scene-create": {
      var newScene = {
        id: "scene-ai" + seq,
        name: payload.name || "场景 " + seq,
        isMain: !!payload.isMain,
        tracks: { overlay: [], main: makeTrack("video", seq, "Main"), audio: [] },
        bookmarks: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      project.scenes.push(newScene);
      if (payload.isMain) {
        for (var mc = 0; mc < project.scenes.length; mc++) project.scenes[mc].isMain = false;
        newScene.isMain = true;
      }
      result.sceneId = newScene.id;
      break;
    }
    case "scene-rename": {
      var sc = findScene(project, payload.sceneId);
      if (!sc) throw new Error("scene-rename: scene not found");
      sc.name = payload.name;
      break;
    }
    case "scene-delete": {
      var delIdx = -1;
      var delScene = null;
      for (var ds = 0; ds < project.scenes.length; ds++) {
        if (project.scenes[ds].id === payload.sceneId) { delIdx = ds; delScene = project.scenes[ds]; break; }
      }
      if (!delScene) throw new Error("scene-delete: scene not found");
      if (delScene.isMain) throw new Error("scene-delete: cannot delete main scene");
      project.scenes.splice(delIdx, 1);
      break;
    }
    case "bookmark-add": {
      var bmScene = findScene(project, payload.sceneId);
      if (!bmScene.bookmarks) bmScene.bookmarks = [];
      var btime = tickOf(payload.timeSec);
      var exists = false;
      for (var bi = 0; bi < bmScene.bookmarks.length; bi++) {
        if (bmScene.bookmarks[bi].time === btime) { exists = true; break; }
      }
      if (!exists) bmScene.bookmarks.push({ time: btime, note: payload.note || null });
      break;
    }
    case "bookmark-remove": {
      var brScene = findScene(project, payload.sceneId);
      if (!brScene.bookmarks) break;
      var brt = tickOf(payload.timeSec);
      brScene.bookmarks = brScene.bookmarks.filter(function (b) { return b.time !== brt; });
      break;
    }
    case "settings": {
      if (!project.settings) project.settings = {};
      if (payload.fps) project.settings.fps = payload.fps;
      if (payload.canvasSize) project.settings.canvasSize = payload.canvasSize;
      if (payload.background) project.settings.background = payload.background;
      break;
    }
    default:
      throw new Error("applyOp: unknown op type " + op.type);
  }
  return result;
}

// ---- 校验 ------------------------------------------------------------------
function validateTimeline(project, registeredAssets, componentIds) {
  var violations = [];
  var assetSet = new Set(registeredAssets || []);
  var componentSet = new Set(componentIds || []);
  var scenes = project && Array.isArray(project.scenes) ? project.scenes : [];
  for (var s = 0; s < scenes.length; s++) {
    var scene = scenes[s];
    var tracks = sceneTracks(scene);
    var allTracks = [];
    if (tracks.main) allTracks.push(tracks.main);
    allTracks = allTracks.concat(tracks.overlay || []).concat(tracks.audio || []);
    for (var t = 0; t < allTracks.length; t++) {
      var track = allTracks[t];
      var elements = track.elements || [];
      for (var e = 0; e < elements.length; e++) {
        var el = elements[e];
        if (el.mediaId && !assetSet.has(el.mediaId)) {
          violations.push({ code: "asset-exists", ref: { trackId: track.id, elementId: el.id }, detail: "mediaId not registered: " + el.mediaId });
        }
        if (!el.duration || el.duration <= 0) {
          violations.push({ code: "duration>0", ref: { trackId: track.id, elementId: el.id }, detail: "duration <= 0" });
        }
        if (el.trimEnd !== undefined && el.trimStart > el.trimEnd) {
          violations.push({ code: "out-of-range", ref: { trackId: track.id, elementId: el.id }, detail: "trimStart > trimEnd" });
        }
        if (el.type === "component" && el.componentId && !componentSet.has(el.componentId)) {
          violations.push({ code: "component-def", ref: { trackId: track.id, elementId: el.id }, detail: "unknown componentId: " + el.componentId });
        }
        var bm = el.params && el.params.blendMode;
        if (bm !== undefined && bm !== null && DEFAULT_BLEND_MODES.indexOf(bm) < 0) {
          violations.push({ code: "param-valid", ref: { trackId: track.id, elementId: el.id }, detail: "invalid blendMode: " + bm });
        }
        if (el.params && el.params.opacity !== undefined && (el.params.opacity < 0 || el.params.opacity > 1)) {
          violations.push({ code: "param-valid", ref: { trackId: track.id, elementId: el.id }, detail: "opacity out of [0,1]" });
        }
      }
    }
    // 主轨重叠
    if (tracks.main && tracks.main.elements) {
      var sorted = tracks.main.elements.slice().sort(function (a, b) { return a.startTime - b.startTime; });
      for (var o = 1; o < sorted.length; o++) {
        if (sorted[o].startTime < sorted[o - 1].startTime + sorted[o - 1].duration) {
          violations.push({ code: "overlap", ref: { trackId: tracks.main.id, elementId: sorted[o].id }, detail: "overlaps " + sorted[o - 1].id });
        }
      }
    }
  }
  return violations;
}

// ---- condensed 读取 ---------------------------------------------------------
function condensedClip(el, trackId) {
  var p = el.params || {};
  return {
    ref: { trackId: trackId, elementId: el.id },
    type: el.type,
    name: el.name,
    startSec: secOf(el.startTime),
    durationSec: secOf(el.duration),
    trimStartSec: secOf(el.trimStart),
    trimEndSec: secOf(el.trimEnd),
    params: {
      transform: {
        positionX: p["transform.positionX"] !== undefined ? p["transform.positionX"] : 0,
        positionY: p["transform.positionY"] !== undefined ? p["transform.positionY"] : 0,
        scaleX: p["transform.scaleX"] !== undefined ? p["transform.scaleX"] : 1,
        scaleY: p["transform.scaleY"] !== undefined ? p["transform.scaleY"] : 1,
        rotate: p["transform.rotate"] !== undefined ? p["transform.rotate"] : 0,
      },
      opacity: p.opacity !== undefined ? p.opacity : 1,
      volume: p.volume !== undefined ? p.volume : undefined,
      blendMode: p.blendMode !== undefined ? p.blendMode : "normal",
      text: el.type === "text" ? { content: p.content || "", fontSize: p.fontSize, color: p.color } : undefined,
    },
    keyframeCount: countKeyframes(el),
    effectCount: (el.effects || []).length,
    maskCount: (el.masks || []).length,
    muted: !!(el.isSourceAudioEnabled === false) || !!(p.muted),
    hidden: !!el.hidden,
    mediaId: el.mediaId,
    componentId: el.componentId,
    definitionId: el.definitionId,
    effectType: el.effectType,
    sourceType: el.sourceType,
    sourceUrl: el.sourceUrl,
  };
}
function countKeyframes(el) {
  if (!el.animations) return 0;
  var n = 0;
  for (var path in el.animations) {
    if (Object.prototype.hasOwnProperty.call(el.animations, path)) {
      n += (el.animations[path].keys || []).length;
    }
  }
  return n;
}

function condensedTimeline(project) {
  var scenes = project && Array.isArray(project.scenes) ? project.scenes : [];
  var clips = [];
  var tracks = [];
  var maxEnd = 0;
  var activeScene = findScene(project, project.currentSceneId);
  var activeSceneId = activeScene ? activeScene.id : (scenes[0] ? scenes[0].id : null);
  for (var s = 0; s < scenes.length; s++) {
    var scene = scenes[s];
    var st = sceneTracks(scene);
    var all = [];
    if (st.main) all.push(st.main);
    all = all.concat(st.overlay || []).concat(st.audio || []);
    for (var t = 0; t < all.length; t++) {
      var track = all[t];
      var els = track.elements || [];
      tracks.push({ trackId: track.id, type: track.type, name: track.name, muted: !!track.muted, hidden: !!track.hidden, clipCount: els.length });
      for (var e = 0; e < els.length; e++) {
        var end = els[e].startTime + els[e].duration;
        if (end > maxEnd) maxEnd = end;
        clips.push(condensedClip(els[e], track.id));
      }
    }
  }
  clips.sort(function (a, b) { return a.startSec - b.startSec; });
  return {
    currentSceneId: activeSceneId,
    durationSec: maxEnd / TICKS_PER_SECOND,
    tracks: tracks,
    clips: clips,
    settings: project.settings || null,
  };
}

function elementDetail(project, ref) {
  // 跨场景解析：ref 可不带 sceneId，按 trackId+elementId 在全项目内定位
  var scene = ref && ref.sceneId ? findScene(project, ref.sceneId) : null;
  var track = scene && findTrack(scene, ref.trackId);
  var el = track && findElementInTrack(track, ref.elementId);
  if (!el && project && Array.isArray(project.scenes)) {
    for (var s = 0; s < project.scenes.length && !el; s++) {
      track = findTrack(project.scenes[s], ref.trackId);
      el = track && findElementInTrack(track, ref.elementId);
    }
  }
  if (!el) return null;
  var animations = {};
  if (el.animations) {
    for (var path in el.animations) {
      if (Object.prototype.hasOwnProperty.call(el.animations, path)) {
        animations[path] = { keyCount: (el.animations[path].keys || []).length, keys: el.animations[path].keys };
      }
    }
  }
  return {
    ref: { trackId: ref.trackId, elementId: ref.elementId },
    type: el.type,
    name: el.name,
    startSec: secOf(el.startTime),
    startTicks: el.startTime,
    durationSec: secOf(el.duration),
    durationTicks: el.duration,
    trimStartSec: secOf(el.trimStart),
    trimEndSec: secOf(el.trimEnd),
    params: el.params || {},
    animations: animations,
    effects: el.effects || [],
    masks: el.masks || [],
    mediaId: el.mediaId,
    componentId: el.componentId,
    definitionId: el.definitionId,
    effectType: el.effectType,
    sourceType: el.sourceType,
    sourceUrl: el.sourceUrl,
    retime: el.retime || null,
    hidden: !!el.hidden,
  };
}

function cloneJson(x) {
  return JSON.parse(JSON.stringify(x));
}

// ============================================================================
// 存储层
// ============================================================================
function scope(ctx) {
  return ctx.project ? ctx.project.id : "";
}

function ensureSchema(ctx, scopeId) {
  ctx.sqlite.execute(
    "create table if not exists editor_projects (" +
      "project_id text not null primary key, " +
      "project_json text not null, " +
      "registered_assets_json text not null default '[]', " +
      "version integer not null default 1, " +
      "updated_at text not null)",
    [scopeId],
  );
  ctx.sqlite.execute(
    "create table if not exists editor_command_log (" +
      "seq integer not null, " +
      "project_id text not null, " +
      "op_json text not null, " +
      "before_scenes_json text not null, " +
      "base_version integer not null, " +
      "result_version integer not null, " +
      "state text not null default 'done', " +
      "created_at text not null, " +
      "primary key (project_id, seq))",
    [scopeId],
  );
  ctx.sqlite.execute(
    "create table if not exists editor_ai_locks (" +
      "project_id text not null primary key, " +
      "owner text not null, " +
      "since text not null, " +
      "last_op_at text not null)",
    [scopeId],
  );
  ctx.sqlite.execute(
    "create table if not exists editor_components (" +
      "component_id text not null primary key, " +
      "project_id text not null, " +
      "name text not null, " +
      "surface text not null, " +
      "keywords_json text not null default '[]', " +
      "head_version_id text, " +
      "created_at text not null, " +
      "updated_at text not null)",
    [scopeId],
  );
  ctx.sqlite.execute(
    "create table if not exists editor_component_versions (" +
      "version_id text not null primary key, " +
      "component_id text not null, " +
      "version integer not null, " +
      "source text not null, " +
      "bundle_hash text not null, " +
      "bundle text not null, " +
      "inputs_json text not null, " +
      "status text not null default 'draft', " +
      "test_report_json text, " +
      "created_at text not null, " +
      "verified_at text)",
    [scopeId],
  );
}

function nowIso() {
  return new Date().toISOString();
}

function readProject(ctx, scopeId) {
  ensureSchema(ctx, scopeId);
  var rows = ctx.sqlite.query(
    "select project_json, registered_assets_json, version, updated_at from editor_projects where project_id = ?",
    [scopeId],
  );
  if (!rows || rows.length === 0) {
    return null;
  }
  var row = rows[0];
  var project = null;
  try {
    project = JSON.parse(row.project_json);
  } catch (e) {
    project = null;
  }
  return {
    project: project,
    registeredAssets: JSON.parse(row.registered_assets_json || "[]"),
    version: row.version,
    updatedAt: row.updated_at,
  };
}

function writeProject(ctx, scopeId, project, registeredAssets, version, baseVersion) {
  ensureSchema(ctx, scopeId);
  var existing = readProject(ctx, scopeId);
  var current = existing ? existing.version : 0;
  if (baseVersion !== undefined && baseVersion !== null && current !== baseVersion) {
    return { ok: false, conflict: true, currentVersion: current };
  }
  var nextVersion = (existing && existing.version) ? existing.version + 1 : 1;
  var nextRegistered = registeredAssets !== undefined && registeredAssets !== null
    ? registeredAssets
    : (existing ? existing.registeredAssets : []);
  var projectWithVersion = project ? Object.assign({}, project, { version: nextVersion }) : project;
  var changed = ctx.sqlite.execute(
    "insert into editor_projects (project_id, project_json, registered_assets_json, version, updated_at) values (?, ?, ?, ?, ?) " +
      "on conflict(project_id) do update set " +
      "project_json = excluded.project_json, registered_assets_json = excluded.registered_assets_json, " +
      "version = excluded.version, updated_at = excluded.updated_at " +
      "where editor_projects.version = ?",
    [scopeId, JSON.stringify(projectWithVersion), JSON.stringify(nextRegistered), nextVersion, nowIso(), current],
  );
  if (!changed || !changed.rowsAffected) {
    return { ok: false, conflict: true, currentVersion: current };
  }
  return { ok: true, version: nextVersion, registeredAssets: nextRegistered };
}

function readLock(ctx, scopeId) {
  var rows = ctx.sqlite.query(
    "select owner, since, last_op_at from editor_ai_locks where project_id = ?",
    [scopeId],
  );
  if (!rows || rows.length === 0) return null;
  var r = rows[0];
  return { owner: r.owner, since: r.since, lastOpAt: r.last_op_at };
}

function writeLock(ctx, scopeId, owner) {
  ctx.sqlite.execute(
    "insert into editor_ai_locks (project_id, owner, since, last_op_at) values (?, ?, ?, ?) " +
      "on conflict(project_id) do update set owner = excluded.owner, since = excluded.since, last_op_at = excluded.last_op_at",
    [scopeId, owner, nowIso(), nowIso()],
  );
}
function clearLock(ctx, scopeId) {
  ctx.sqlite.execute("delete from editor_ai_locks where project_id = ?", [scopeId]);
}
function touchLock(ctx, scopeId) {
  ctx.sqlite.execute("update editor_ai_locks set last_op_at = ? where project_id = ?", [nowIso(), scopeId]);
}

function emitProjectEvent(ctx, scopeId, eventType, payload) {
  if (ctx.project && typeof ctx.project.emit === "function") {
    try {
      ctx.project.emit(eventType, payload || {});
    } catch (e) {
      // 事件广播尽力而为，失败不影响写操作
    }
  }
}

function emitDocumentChanged(ctx, scopeId, version, source) {
  emitProjectEvent(ctx, scopeId, "project.document.changed", { version: version, source: source || "agent" });
}
var AI_LOCK_TIMEOUT_MS = 5 * 60 * 1000;
function lockExpired(lock) {
  if (!lock) return false;
  return Date.now() - new Date(lock.lastOpAt).getTime() > AI_LOCK_TIMEOUT_MS;
}

function nextLogSeq(ctx, scopeId) {
  var rows = ctx.sqlite.query(
    "select coalesce(max(seq), 0) as m from editor_command_log where project_id = ?",
    [scopeId],
  );
  return (rows && rows.length ? Number(rows[0].m) : 0) + 1;
}

// 事务式：apply op → 快照 → 落库 → append 日志 → version 递增
function executeCommand(ctx, scopeId, op) {
  ensureSchema(ctx, scopeId);
  var existing = readProject(ctx, scopeId);
  if (!existing || !existing.project) {
    throw new Error("timeline.command: project not found, run project.create first");
  }
  var baseVersion = op && op.baseVersion !== undefined && op.baseVersion !== null ? op.baseVersion : existing.version;
  if (baseVersion !== existing.version) {
    return { ok: false, conflict: true, currentVersion: existing.version, opsSince: logSince(ctx, scopeId, baseVersion) };
  }
  var seq = nextLogSeq(ctx, scopeId);
  var project = cloneJson(existing.project);
  // 快照整份 project（scenes + settings + currentSceneId），保证 undo 对所有 op 语义正确
  var beforeProject = cloneJson(project);
  var result;
  try {
    result = applyOp(project, { type: op.type, payload: op.payload || {} }, { seq: seq });
  } catch (e) {
    return { ok: false, error: e.message };
  }
  project.metadata = project.metadata || { id: scopeId, name: "未命名剪辑" };
  project.metadata.updatedAt = nowIso();
  var write = writeProject(ctx, scopeId, project, undefined, undefined, existing.version);
  if (!write.ok) {
    return { ok: false, conflict: true, currentVersion: write.currentVersion };
  }
  // 新命令清除 redo 栈（undo 后的条目置为 dropped）
  ctx.sqlite.execute(
    "update editor_command_log set state = 'dropped' where project_id = ? and state = 'undone'",
    [scopeId],
  );
  var storedOp = { type: op.type, payload: op.payload || {} };
  ctx.sqlite.execute(
    "insert into editor_command_log (seq, project_id, op_json, before_scenes_json, base_version, result_version, state, created_at) values (?, ?, ?, ?, ?, ?, 'done', ?)",
    [seq, scopeId, JSON.stringify(storedOp), JSON.stringify(beforeProject), existing.version, write.version, nowIso()],
  );
  var lock = readLock(ctx, scopeId);
  if (lock) touchLock(ctx, scopeId);
  emitDocumentChanged(ctx, scopeId, write.version, "agent");
  return {
    ok: true,
    version: write.version,
    seq: seq,
    result: result,
    changed: true,
    lock: lock ? { owner: lock.owner } : null,
  };
}

function logSince(ctx, scopeId, afterVersion) {
  var rows = ctx.sqlite.query(
    "select op_json from editor_command_log where project_id = ? and result_version > ? order by seq asc",
    [scopeId, afterVersion],
  );
  return (rows || []).map(function (r) { return JSON.parse(r.op_json); });
}

function undoLast(ctx, scopeId) {
  ensureSchema(ctx, scopeId);
  var existing = readProject(ctx, scopeId);
  if (!existing || !existing.project) throw new Error("history: project not found");
  var rows = ctx.sqlite.query(
    "select seq, before_scenes_json from editor_command_log where project_id = ? and state = 'done' order by seq desc limit 1",
    [scopeId],
  );
  if (!rows || rows.length === 0) return { ok: false, reason: "nothing-to-undo" };
  var row = rows[0];
  var project;
  try {
    project = row.before_scenes_json ? JSON.parse(row.before_scenes_json) : cloneJson(existing.project);
  } catch (e) {
    return { ok: false, error: "corrupt undo snapshot" };
  }
  project.metadata = project.metadata || { id: scopeId, name: "未命名剪辑" };
  project.metadata.updatedAt = nowIso();
  var write = writeProject(ctx, scopeId, project, undefined, undefined, existing.version);
  if (!write.ok) return { ok: false, conflict: true, currentVersion: write.currentVersion };
  ctx.sqlite.execute(
    "update editor_command_log set state = 'undone' where project_id = ? and seq = ?",
    [scopeId, row.seq],
  );
  emitDocumentChanged(ctx, scopeId, write.version, "agent");
  return { ok: true, version: write.version, undidSeq: row.seq };
}

function redoNext(ctx, scopeId) {
  ensureSchema(ctx, scopeId);
  var existing = readProject(ctx, scopeId);
  if (!existing || !existing.project) throw new Error("history: project not found");
  var rows = ctx.sqlite.query(
    "select seq, op_json from editor_command_log where project_id = ? and state = 'undone' order by seq desc limit 1",
    [scopeId],
  );
  if (!rows || rows.length === 0) return { ok: false, reason: "nothing-to-redo" };
  var row = rows[0];
  var op;
  try {
    op = JSON.parse(row.op_json);
  } catch (e) {
    return { ok: false, error: "corrupt op" };
  }
  var project = cloneJson(existing.project);
  var result;
  try {
    result = applyOp(project, op, { seq: row.seq });
  } catch (e) {
    return { ok: false, error: e.message };
  }
  project.metadata.updatedAt = nowIso();
  var write = writeProject(ctx, scopeId, project, undefined, undefined, existing.version);
  if (!write.ok) return { ok: false, conflict: true, currentVersion: write.currentVersion };
  ctx.sqlite.execute(
    "update editor_command_log set state = 'done', result_version = ? where project_id = ? and seq = ?",
    [write.version, scopeId, row.seq],
  );
  emitDocumentChanged(ctx, scopeId, write.version, "agent");
  return { ok: true, version: write.version, redidSeq: row.seq, result: result };
}

function summarizeTimeline(project) {
  var c = condensedTimeline(project);
  return { elements: c.clips.length, tracks: c.tracks.length };
}

function projectDurationTicks(project) {
  var maxEnd = 0;
  var scenes = project && Array.isArray(project.scenes) ? project.scenes : [];
  for (var s = 0; s < scenes.length; s++) {
    var st = sceneTracks(scenes[s]);
    var all = [];
    if (st.main) all.push(st.main);
    all = all.concat(st.overlay || []).concat(st.audio || []);
    for (var t = 0; t < all.length; t++) {
      var els = all[t].elements || [];
      for (var e = 0; e < els.length; e++) {
        var end = els[e].startTime + els[e].duration;
        if (end > maxEnd) maxEnd = end;
      }
    }
  }
  return maxEnd;
}

function makeDefaultProject({ scopeId, name, settings, materialAssetIds }) {
  var now = nowIso();
  var mainTrackId = "track-main-" + Math.random().toString(36).slice(2, 10);
  var sceneId = "scene-" + Math.random().toString(36).slice(2, 10);
  var fps = (settings && settings.fps) || DEFAULT_FPS;
  var canvasSize = (settings && settings.canvasSize) || DEFAULT_CANVAS;
  var background = (settings && settings.background) || { type: "color", color: "#000000" };
  return {
    metadata: { id: scopeId, name: name || "未命名剪辑", thumbnail: null, duration: 0, createdAt: now, updatedAt: now },
    scenes: [
      {
        id: sceneId,
        name: "Main scene",
        isMain: true,
        tracks: { overlay: [], main: { id: mainTrackId, name: "Main", type: "video", elements: [], muted: false, hidden: false }, audio: [] },
        bookmarks: [],
        createdAt: now,
        updatedAt: now,
      },
    ],
    currentSceneId: sceneId,
    settings: { fps: fps, canvasSize: canvasSize, background: background },
    version: 1,
    materialAssetIds: materialAssetIds || [],
  };
}

function collectTimelineAssetIds(project) {
  var ids = new Set((project && project.materialAssetIds) || []);
  var scenes = project && Array.isArray(project.scenes) ? project.scenes : [];
  for (var s = 0; s < scenes.length; s++) {
    var st = sceneTracks(scenes[s]);
    var all = [];
    if (st.main) all.push(st.main);
    all = all.concat(st.overlay || []).concat(st.audio || []);
    for (var t = 0; t < all.length; t++) {
      var els = all[t].elements || [];
      for (var e = 0; e < els.length; e++) {
        if (els[e].mediaId) ids.add(els[e].mediaId);
        if (els[e].sourceUrl) ids.add(els[e].sourceUrl);
      }
    }
  }
  return Array.from(ids);
}

// ============================================================================
// 操作
// ============================================================================
recut.operation.register("project.create", (input, ctx) => {
  const scopeId = scope(ctx);
  const now = nowIso();
  const project = makeDefaultProject({
    scopeId,
    name: input && input.name,
    settings: input && input.settings,
    materialAssetIds: input && input.materialAssetIds,
  });
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "insert into editor_projects (project_id, project_json, registered_assets_json, version, updated_at) values (?, ?, ?, ?, ?) " +
      "on conflict(project_id) do update set " +
      "project_json = excluded.project_json, registered_assets_json = excluded.registered_assets_json, " +
      "version = excluded.version, updated_at = excluded.updated_at",
    [scopeId, JSON.stringify(project), JSON.stringify((input && input.materialAssetIds) || []), 1, now],
  );
  return { projectId: scopeId, project, version: 1 };
});

recut.operation.register("project.load", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  if (!existing || !existing.project) {
    const project = makeDefaultProject({ scopeId, name: undefined });
    writeProject(ctx, scopeId, project, [], 1);
    return { project, registeredAssets: [], version: 1 };
  }
  return { project: existing.project, registeredAssets: existing.registeredAssets, version: existing.version };
});

recut.operation.register("project.save", (input, ctx) => {
  const scopeId = scope(ctx);
  if (!input || !input.project) {
    throw new Error("project.save: missing project");
  }
  const lock = readLock(ctx, scopeId);
  if (lock && !lockExpired(lock)) {
    return { ok: false, locked: true, lock: { owner: lock.owner } };
  }
  const baseVersion = input.baseVersion !== undefined && input.baseVersion !== null ? input.baseVersion : undefined;
  const write = writeProject(ctx, scopeId, input.project, undefined, undefined, baseVersion);
  if (!write.ok) {
    return { ok: false, conflict: true, currentVersion: write.currentVersion };
  }
  emitDocumentChanged(ctx, scopeId, write.version, "ui");
  return { ok: true, version: write.version, savedAt: nowIso() };
});

recut.operation.register("workflow.context", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  const project = existing && existing.project;
  const c = condensedTimeline(project);
  const lock = readLock(ctx, scopeId);
  const hasElements = c.clips.length > 0;
  const locked = !!(lock && !lockExpired(lock));
  return {
    projectId: scopeId,
    stage: hasElements ? "editing" : "brief",
    settings: project && project.settings ? project.settings : null,
    timeline: { elements: c.clips.length, tracks: c.tracks.length },
    durationSeconds: c.durationSec,
    registeredAssets: (existing && existing.registeredAssets) || [],
    version: existing ? existing.version : 0,
    aiLock: locked ? { owner: lock.owner, since: lock.since } : null,
    nextAction: hasElements ? "edit_timeline" : "create_project",
    allowedActions: hasElements
      ? ["timeline.read", "element.get", "timeline.validate", "timeline.command", "history.undo", "project.lock", "project.unlock", "timeline.assets", "component.define", "component.verify", "component.list", "component.source", "film.package.import"]
      : ["project.create", "film.package.import", "timeline.command", "component.define", "component.list"],
    paths: { appRoot: ctx.paths ? ctx.paths.appRoot : null, projectFilesRoot: ctx.paths ? ctx.paths.projectFilesRoot : null },
  };
});

recut.operation.register("project.get", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  const project = existing && existing.project;
  const lock = readLock(ctx, scopeId);
  return {
    name: project && project.metadata ? project.metadata.name : null,
    settings: project && project.settings ? project.settings : null,
    version: existing ? existing.version : 0,
    durationSec: projectDurationTicks(project) / TICKS_PER_SECOND,
    materialAssetIds: (project && project.materialAssetIds) || [],
    registeredAssets: (existing && existing.registeredAssets) || [],
    aiLock: lock && !lockExpired(lock) ? { owner: lock.owner, since: lock.since } : null,
  };
});

recut.operation.register("timeline.read", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  const project = existing && existing.project;
  const c = condensedTimeline(project);
  const lock = readLock(ctx, scopeId);
  return {
    version: existing ? existing.version : 0,
    currentSceneId: c.currentSceneId,
    durationSec: c.durationSec,
    settings: c.settings,
    tracks: c.tracks,
    clips: c.clips,
    aiLock: lock && !lockExpired(lock) ? { owner: lock.owner } : null,
  };
});

recut.operation.register("element.get", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  if (!input || !input.trackId || !input.elementId) {
    throw new Error("element.get: trackId + elementId required");
  }
  const detail = elementDetail(existing && existing.project, { trackId: input.trackId, elementId: input.elementId });
  if (!detail) throw new Error("element.get: element not found");
  return { version: existing.version, element: detail };
});

recut.operation.register("timeline.validate", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  const compRows = ctx.sqlite.query(
    "select component_id from editor_components where project_id = ?",
    [scopeId],
  );
  const componentIds = (compRows || []).map((r) => r.component_id);
  const violations = validateTimeline(existing && existing.project, existing && existing.registeredAssets, componentIds);
  return { version: existing ? existing.version : 0, ok: violations.length === 0, violations };
});

recut.operation.register("timeline.assets", (input, ctx) => {
  const scopeId = scope(ctx);
  if (!Array.isArray(input && input.assetIds)) {
    throw new Error("timeline.assets: assetIds array required");
  }
  const unique = Array.from(new Set(input.assetIds));
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "update editor_projects set registered_assets_json = ?, updated_at = ? where project_id = ?",
    [JSON.stringify(unique), nowIso(), scopeId],
  );
  return { registered: unique.length, assetIds: unique };
});

recut.operation.register("project.updateSettings", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  if (!existing || !existing.project) throw new Error("project.updateSettings: project not found");
  const op = {
    type: "settings",
    payload: {
      fps: input && input.fps,
      canvasSize: input && input.canvasSize,
      background: input && input.background,
    },
  };
  if (input && input.baseVersion !== undefined && input.baseVersion !== null) {
    op.baseVersion = input.baseVersion;
  }
  const out = executeCommand(ctx, scopeId, op);
  if (out.ok) {
    const cur = readProject(ctx, scopeId);
    out.settings = cur && cur.project && cur.project.settings;
  }
  return out;
});

recut.operation.register("project.lock", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  if (!existing || !existing.project) throw new Error("project.lock: project not found");
  const lock = readLock(ctx, scopeId);
  if (lock && !lockExpired(lock)) {
    return { ok: false, locked: true, lock: { owner: lock.owner } };
  }
  const owner = (input && input.owner) || "agent";
  writeLock(ctx, scopeId, owner);
  emitProjectEvent(ctx, scopeId, "project:locked", { owner: owner, version: existing.version });
  return { ok: true, lock: { owner, since: nowIso() }, version: existing.version };
});

recut.operation.register("project.unlock", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  clearLock(ctx, scopeId);
  emitProjectEvent(ctx, scopeId, "project:unlocked", { version: existing ? existing.version : 0 });
  emitDocumentChanged(ctx, scopeId, existing ? existing.version : 0, "agent");
  return { ok: true, version: existing ? existing.version : 0 };
});

recut.operation.register("timeline.command", (input, ctx) => {
  const scopeId = scope(ctx);
  if (!input || !input.op || !input.op.type) {
    throw new Error("timeline.command: op required");
  }
  return executeCommand(ctx, scopeId, input.op);
});

recut.operation.register("history.undo", (input, ctx) => {
  const scopeId = scope(ctx);
  return undoLast(ctx, scopeId);
});

recut.operation.register("history.redo", (input, ctx) => {
  const scopeId = scope(ctx);
  return redoNext(ctx, scopeId);
});

// ---- 导出（UI 驱动）----
recut.operation.register("export.start", (input, ctx) => {
  const scopeId = scope(ctx);
  const existing = readProject(ctx, scopeId);
  const exportId = "export-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "create table if not exists editor_exports (" +
      "export_id text not null primary key, project_id text not null, settings_json text not null, " +
      "asset_id text, status text not null, created_at text not null, updated_at text not null)",
  );
  const w = (existing && existing.project && existing.project.settings && existing.project.settings.canvasSize) || DEFAULT_CANVAS;
  ctx.sqlite.execute(
    "insert into editor_exports (export_id, project_id, settings_json, status, created_at, updated_at) values (?, ?, ?, 'encoding', ?, ?)",
    [exportId, scopeId, JSON.stringify({ width: (input && input.width) || w.width, height: (input && input.height) || w.height, fps: (input && input.fps) || 30, mode: (input && input.mode) || "ui" }), nowIso(), nowIso()],
  );
  return { exportId };
});

recut.operation.register("export.progress", (input, ctx) => {
  if (!input || !input.exportId || typeof input.progress !== "number") {
    throw new Error("export.progress: exportId + progress required");
  }
  return { exportId: input.exportId, progress: Math.max(0, Math.min(1, input.progress)) };
});

recut.operation.register("export.complete", (input, ctx) => {
  const scopeId = scope(ctx);
  if (!input || !input.exportId || !input.fileBase64) {
    throw new Error("export.complete: exportId + fileBase64 required");
  }
  const b64Path = "exports/" + input.exportId + ".b64";
  const mp4Path = "exports/" + input.exportId + ".mp4";
  ctx.files.writeText(b64Path, input.fileBase64);
  const scriptPath = ctx.paths.appRoot + "/scripts/decode-base64.js";
  ctx.shell.exec({ command: "node", args: [scriptPath, b64Path, mp4Path], cwd: "files", timeoutSeconds: 300 });
  const name = input.name || "成片 " + input.exportId;
  const asset = ctx.media.importFile({ path: mp4Path, name, mimeType: input.mimeType || "video/mp4" });
  if (asset && asset.id) {
    ctx.project.setCover({ assetId: asset.id });
  }
  ensureSchema(ctx, scopeId);
  ctx.sqlite.execute(
    "update editor_exports set asset_id = ?, status = 'completed', updated_at = ? where export_id = ?",
    [asset && asset.id, nowIso(), input.exportId],
  );
  return { exportId: input.exportId, assetId: asset && asset.id };
});

recut.operation.register("export.list", (input, ctx) => {
  const scopeId = scope(ctx);
  ensureSchema(ctx, scopeId);
  const rows = ctx.sqlite.query(
    "select export_id, settings_json, asset_id, status, created_at from editor_exports where project_id = ? order by created_at desc",
    [scopeId],
  );
  return { exports: rows || [] };
});

// ---- 首帧封面（UI 驱动，非 media Asset）----
// 编辑器渲染首帧后经此 op 更新项目封面。图片字节写入项目文件根（app files
// CDN 语义），再登记为 file 封面；不产生 media Asset，可频繁刷新不污染素材库。
// 由 UI 侧去抖（空闲）+ 节流 + 帧 hash 变化时才调用。
recut.operation.register("cover.update", (input, ctx) => {
  if (!input || !input.fileBase64) {
    throw new Error("cover.update: fileBase64 required");
  }
  const mimeType = input.mimeType || "image/png";
  const ext = mimeType === "image/png" ? ".png" : mimeType === "image/jpeg" ? ".jpg" : mimeType === "image/webp" ? ".webp" : ".png";
  const path = "covers/cover" + ext;
  ctx.files.writeBase64(path, input.fileBase64);
  const updated = ctx.project.setCoverImage({ path: path, mimeType: mimeType });
  return { ok: true, path: path, cover: updated && updated.cover ? updated.cover : null };
});

recut.operation.register("film.package.import", (input, ctx) => {
  const scopeId = scope(ctx);
  const pkg = (input && input.pkg) || input;
  if (!pkg) {
    throw new Error("film.package.import: pkg required");
  }
  const existing = readProject(ctx, scopeId);
  const baseProject = (existing && existing.project) || makeDefaultProject({ scopeId, name: "AI 短片草稿" });
  const project = cloneJson(baseProject);
  const now = nowIso();
  const scene = findScene(project, project.currentSceneId);
  const tracks = sceneTracks(scene);

  const addElement = (track, element) => {
    if (!track || !track.elements) {
      throw new Error("addElement: track has no elements array: " + JSON.stringify({ trackName: track && track.name, hasElements: !!(track && track.elements) }));
    }
    track.elements.push(element);
  };

  const ensureTextTrack = () => findOrCreateTrack(scene, "text", 0, undefined);
  const ensureAudioTrack = () => findOrCreateTrack(scene, "audio", 0, undefined);

  const scenes = pkg.scenes || [];
  const script = pkg.script || { beats: [] };

  let cursor = 0;
  const beats = script.beats || (typeof script === "string" ? [] : []);
  for (let i = 0; i < scenes.length; i++) {
    const sc = scenes[i];
    const assetIds = sc.assetIds || sc.imageAssetIds || [];
    const durationSec = sc.durationSeconds || sc.durationSec || 5;
    const startTicks = tickOf(cursor);

    for (const assetId of assetIds) {
      addElement(tracks.main, {
        id: "el-" + i + "-" + String(assetId).slice(-8),
        name: sc.title || "镜头 " + (i + 1),
        type: "video",
        mediaId: assetId,
        startTime: startTicks,
        duration: tickOf(durationSec),
        trimStart: 0,
        trimEnd: tickOf(durationSec),
        params: Object.assign({}, CORE_DEFAULT_PARAMS),
        hidden: false,
      });
    }

    if (sc.title && sc.title !== "镜头 " + (i + 1)) {
      addElement(ensureTextTrack(), {
        id: "el-text-" + i,
        name: sc.title,
        type: "text",
        startTime: startTicks,
        duration: tickOf(durationSec),
        trimStart: 0,
        trimEnd: tickOf(durationSec),
        params: Object.assign({}, coreParamsForType("text"), { content: sc.title }),
        hidden: false,
      });
    }
    cursor += durationSec;
  }

  if (pkg.audio && pkg.audio.voiceoverAssetId) {
    addElement(ensureAudioTrack(), {
      id: "el-vo-" + Date.now().toString(36),
      name: "配音",
      type: "audio",
      sourceType: "upload",
      mediaId: pkg.audio.voiceoverAssetId,
      startTime: 0,
      duration: tickOf(pkg.audio.durationSeconds || cursor || 10),
      trimStart: 0,
      trimEnd: tickOf(pkg.audio.durationSeconds || cursor || 10),
      params: Object.assign({}, CORE_DEFAULT_AUDIO_PARAMS),
    });
  }

  project.metadata.updatedAt = now;
  scene.updatedAt = now;
  const write = writeProject(ctx, scopeId, project, undefined, undefined);
  if (write.ok) emitDocumentChanged(ctx, scopeId, write.version, "agent");
  return { ok: true, elements: summarizeTimeline(project) };
});

/* ------------------------------------------------------------------ *
 * AI 临时组件（Temp Components）
 * 项目作用域，逻辑组件 + 不可变版本（source+bundle 同版本持有）。
 * 时间线钉 componentId，head 跟随 = 最新 verified 版本；失败永不渲染。
 * ------------------------------------------------------------------ */

var COMPONENT_SURFACES = ["html", "react", "r3f"];

function newComponentId() {
  return "ai-" + Math.random().toString(36).slice(2, 10);
}

function readComponent(ctx, scopeId, componentId) {
  ensureSchema(ctx, scopeId);
  var rows = ctx.sqlite.query(
    "select * from editor_components where component_id = ? and project_id = ?",
    [componentId, scopeId],
  );
  return rows && rows.length > 0 ? rows[0] : null;
}

function readVersion(ctx, scopeId, versionId) {
  ensureSchema(ctx, scopeId);
  var rows = ctx.sqlite.query(
    "select * from editor_component_versions where version_id = ?",
    [versionId],
  );
  return rows && rows.length > 0 ? rows[0] : null;
}

function latestVersion(ctx, scopeId, componentId) {
  ensureSchema(ctx, scopeId);
  var rows = ctx.sqlite.query(
    "select version_id from editor_component_versions where component_id = ? order by version desc limit 1",
    [componentId],
  );
  return rows && rows.length > 0 ? rows[0].version_id : null;
}

function headVersion(ctx, scopeId, componentId) {
  ensureSchema(ctx, scopeId);
  var rows = ctx.sqlite.query(
    "select v.version_id, v.status, v.bundle, v.bundle_hash, v.inputs_json, v.test_report_json " +
      "from editor_component_versions v " +
      "where v.version_id = (select head_version_id from editor_components where component_id = ? and project_id = ?)",
    [componentId, scopeId],
  );
  return rows && rows.length > 0 ? rows[0] : null;
}

/** 构建组件 bundle：写源文件 → 跑 component-build.js（esbuild+tsc+确定性扫描）→ 读产物。 */
function buildComponentBundle(ctx, versionId, source) {
  var sourcePath = "components/" + versionId + ".tsx";
  var outPath = "components/" + versionId + ".js";
  ctx.files.writeText(sourcePath, source);
  var buildScript = ctx.paths.appRoot + "/scripts/component-build.js";
  var sdkDir = ctx.paths.appRoot + "/sdk";
  var result = ctx.shell.exec({
    command: "node",
    args: [buildScript, sourcePath, outPath, sdkDir],
    cwd: "files",
    timeoutSeconds: 60,
  });
  var parsed = null;
  try {
    parsed = JSON.parse((result && (result.stdout || result.output)) || "{}");
  } catch (_) {
    parsed = null;
  }
  if (!parsed || parsed.ok !== true) {
    return {
      ok: false,
      error: parsed && parsed.error,
      type: parsed && parsed.type,
      issues: parsed && parsed.issues,
      errors: parsed && parsed.errors,
    };
  }
  var bundle = ctx.files.readText(outPath);
  return { ok: true, bundle: bundle, bundleHash: parsed.bundleHash };
}

function parseJson(value, fallback) {
  try {
    return JSON.parse(value);
  } catch (_) {
    return fallback;
  }
}

/** 新建临时组件或已有组件的新版本（AI 二次调整 = 带 componentId 重 define）。 */
recut.operation.register("component.define", (input, ctx) => {
  var scopeId = scope(ctx);
  if (!ctx.project) {
    throw new Error("component.define: 需要项目上下文");
  }
  if (!input || typeof input.source !== "string" || !input.source.trim()) {
    throw new Error("component.define: source 必填");
  }
  var surface = input.surface || "r3f";
  if (COMPONENT_SURFACES.indexOf(surface) === -1) {
    throw new Error("component.define: surface 非法: " + surface);
  }
  var componentId = input.componentId || newComponentId();
  var name = input.name || "AI 组件";
  var keywords = Array.isArray(input.keywords) ? input.keywords : [];
  var inputs = Array.isArray(input.inputs) ? input.inputs : [];
  var now = nowIso();
  ensureSchema(ctx, scopeId);

  var existing = readComponent(ctx, scopeId, componentId);
  if (!existing) {
    ctx.sqlite.execute(
      "insert into editor_components (component_id, project_id, name, surface, keywords_json, head_version_id, created_at, updated_at) values (?, ?, ?, ?, ?, null, ?, ?)",
      [componentId, scopeId, name, surface, JSON.stringify(keywords), now, now],
    );
  } else {
    ctx.sqlite.execute(
      "update editor_components set name = ?, surface = ?, keywords_json = ?, updated_at = ? where component_id = ?",
      [name, surface, JSON.stringify(keywords), now, componentId],
    );
  }

  var prev = latestVersion(ctx, scopeId, componentId);
  var version = prev ? parseInt(prev.split("@").pop(), 10) + 1 : 1;
  var versionId = componentId + "@" + version;
  var built = buildComponentBundle(ctx, versionId, input.source);

  if (built.ok) {
    ctx.sqlite.execute(
      "insert into editor_component_versions (version_id, component_id, version, source, bundle_hash, bundle, inputs_json, status, test_report_json, created_at, verified_at) values (?, ?, ?, ?, ?, ?, ?, 'draft', null, ?, null)",
      [versionId, componentId, version, input.source, built.bundleHash, built.bundle, JSON.stringify(inputs), now],
    );
    return { componentId: componentId, versionId: versionId, version: version, status: "draft" };
  }

  // 构建失败：记录 failed 版本（含错误报告），供 AI 读错误迭代；head 不动。
  ctx.sqlite.execute(
    "insert into editor_component_versions (version_id, component_id, version, source, bundle_hash, bundle, inputs_json, status, test_report_json, created_at, verified_at) values (?, ?, ?, ?, '', '', ?, 'failed', ?, ?, null)",
    [versionId, componentId, version, input.source, JSON.stringify(inputs), JSON.stringify(built), now],
  );
  return { componentId: componentId, versionId: versionId, version: version, status: "failed", buildError: built };
});

/** 验证：浏览器 harness 渲染后回传 report（ok→verified 并更新 head）；无 report 时返回当前状态。 */
recut.operation.register("component.verify", (input, ctx) => {
  var scopeId = scope(ctx);
  var versionId = input && input.versionId;
  if (!versionId) {
    throw new Error("component.verify: versionId 必填");
  }
  var row = readVersion(ctx, scopeId, versionId);
  if (!row) {
    throw new Error("component.verify: 版本不存在 " + versionId);
  }
  if (input && input.report) {
    var status = input.report.ok === true ? "verified" : "failed";
    var now = nowIso();
    ctx.sqlite.execute(
      "update editor_component_versions set status = ?, test_report_json = ?, verified_at = ? where version_id = ?",
      [status, JSON.stringify(input.report), status === "verified" ? now : null, versionId],
    );
    if (status === "verified") {
      ctx.sqlite.execute(
        "update editor_components set head_version_id = ?, updated_at = ? where component_id = ? and project_id = ?",
        [versionId, now, row.component_id, scopeId],
      );
    }
    return { versionId: versionId, status: status, report: input.report };
  }
  return {
    versionId: versionId,
    componentId: row.component_id,
    status: row.status,
    report: parseJson(row.test_report_json, null),
  };
});

/** 项目内组件列表（含 head 状态与 inputs，AI 建 clip 时据此构造 params 默认值）。 */
recut.operation.register("component.list", (input, ctx) => {
  var scopeId = scope(ctx);
  ensureSchema(ctx, scopeId);
  var rows = ctx.sqlite.query(
    "select c.component_id, c.name, c.surface, c.keywords_json, c.head_version_id, " +
      "v.version, v.status, v.inputs_json, v.test_report_json " +
      "from editor_components c " +
      "left join editor_component_versions v on v.version_id = c.head_version_id " +
      "where c.project_id = ? order by c.updated_at desc",
    [scopeId],
  );
  return {
    components: (rows || []).map(function (r) {
      return {
        componentId: r.component_id,
        name: r.name,
        surface: r.surface,
        keywords: parseJson(r.keywords_json, []),
        version: r.version || null,
        status: r.status || "draft",
        inputs: parseJson(r.inputs_json, []),
        testReport: parseJson(r.test_report_json, null),
      };
    }),
  };
});

/** 读某版本源码（AI 二次调整的权威输入）。 */
recut.operation.register("component.source", (input, ctx) => {
  var scopeId = scope(ctx);
  var componentId = input && input.componentId;
  if (!componentId) {
    throw new Error("component.source: componentId 必填");
  }
  var versionId = input.versionId || latestVersion(ctx, scopeId, componentId);
  if (!versionId) {
    throw new Error("component.source: 无版本 " + componentId);
  }
  var row = readVersion(ctx, scopeId, versionId);
  return { componentId: componentId, versionId: versionId, version: row.version, source: row.source };
});

/** 解析组件 bundle：iframe loader 用。按 versionId 解析精确版本（harness 验证）；按 ids 解析 head（时间线渲染）。 */
recut.operation.register("component.resolve", (input, ctx) => {
  var scopeId = scope(ctx);
  ensureSchema(ctx, scopeId);
  var out = [];
  if (input && input.versionId) {
    var row = readVersion(ctx, scopeId, input.versionId);
    if (row) {
      var comp = readComponent(ctx, scopeId, row.component_id);
      out.push({
        componentId: row.component_id,
        versionId: row.version_id,
        name: comp ? comp.name : row.component_id,
        surface: comp ? comp.surface : "r3f",
        status: row.status,
        inputs: parseJson(row.inputs_json, []),
        bundle: row.bundle,
        bundleHash: row.bundle_hash,
      });
    }
  } else {
    var ids = Array.isArray(input && input.ids) ? input.ids : [];
    for (var i = 0; i < ids.length; i++) {
      var comp2 = readComponent(ctx, scopeId, ids[i]);
      if (!comp2) continue;
      var head = headVersion(ctx, scopeId, ids[i]);
      if (!head) continue; // 无 head → 消费方显示占位
      out.push({
        componentId: ids[i],
        versionId: comp2.head_version_id,
        name: comp2.name,
        surface: comp2.surface,
        status: head.status,
        inputs: parseJson(head.inputs_json, []),
        bundle: head.bundle,
        bundleHash: head.bundle_hash,
      });
    }
  }
  return { components: out };
});
