#!/usr/bin/env node
/**
 * L0 Model API 测试：把 background.js 载入 node vm（recut 桩 + 内存 sqlite mock），
 * 直接调用顶层纯函数与后台操作，验证 AI Model Core 的 op 引擎、D1 关键帧策略、
 * 统一 op 日志（undo/redo/conflict）与 validate。
 * usage: node scripts/test-model-api.js
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const FILE = path.join(__dirname, "..", "background.js");
const source = fs.readFileSync(FILE, "utf8");
const { makeDb } = require("./test-mock");

let failures = 0;
function assert(name, cond, detail) {
  if (cond) {
    console.log(`  ok  ${name}`);
  } else {
    failures += 1;
    console.error(`FAIL  ${name}${detail ? ": " + detail : ""}`);
  }
}

// ---- vm 加载 ----
const recutStub = { operation: { register: () => {} } };
const db = makeDb();
const mockCtx = {
  project: { id: "p1" },
  sqlite: db,
  files: { readText: () => null, writeText: () => {}, list: () => [] },
  shell: { exec: () => ({}) },
  paths: { appRoot: path.join(__dirname, "..") },
  project: { id: "p1", setCover: () => {} },
};
const sandbox = {
  recut: recutStub,
  Date,
  Math,
  JSON,
  Set,
  Map,
  Number,
  String,
  Object,
  Array,
  RegExp,
  console,
};
sandbox.ctx = mockCtx;
vm.createContext(sandbox);
vm.runInContext(source, sandbox);

// ---- 工具 ----
function defaultProject() {
  return JSON.parse(JSON.stringify(sandbox.makeDefaultProject({ scopeId: "p1", name: "t" })));
}
function cmd(op) {
  return sandbox.executeCommand(mockCtx, "p1", op);
}
function findElRef(p, elementId) {
  for (const scene of p.scenes) {
    const t = scene.tracks;
    const all = [];
    if (t.main) all.push(t.main);
    all.push(...(t.overlay || []), ...(t.audio || []));
    for (const track of all) {
      for (const el of track.elements || []) {
        if (el.id === elementId) return { trackId: track.id, elementId: el.id };
      }
    }
  }
  return null;
}
function findEl(p, elementId) {
  for (const scene of p.scenes) {
    const t = scene.tracks;
    const all = [];
    if (t.main) all.push(t.main);
    all.push(...(t.overlay || []), ...(t.audio || []));
    for (const track of all) {
      for (const el of track.elements || []) {
        if (el.id === elementId) return el;
      }
    }
  }
  return null;
}

console.log("\n== applyOp 基础 ==");
{
  const p = defaultProject();
  const res = sandbox.applyOp(p, { type: "insert", payload: { element: { type: "video", name: "A", mediaId: "a1", startSec: 0, durationSec: 2 } } }, { seq: 1 });
  assert("insert 返回 ref", res.refs.length === 1 && res.refs[0].elementId === "el-ai1-0", JSON.stringify(res.refs));
  const c = sandbox.condensedTimeline(p);
  assert("condensed clips=1", c.clips.length === 1);
  assert("condensed 秒换算", c.clips[0].durationSec === 2);
  const v = sandbox.validateTimeline(p, ["a1"]);
  assert("validate 无违规(asset 已登记)", v.length === 0, JSON.stringify(v));
  const v2 = sandbox.validateTimeline(p, []);
  assert("validate asset-exists 命中", v2.length === 1 && v2[0].code === "asset-exists", JSON.stringify(v2));
}

console.log("\n== D1 关键帧策略 ==");
{
  const p = defaultProject();
  sandbox.applyOp(p, { type: "insert", payload: { element: { type: "text", name: "T", startSec: 0, durationSec: 3, content: "Hi" } } }, { seq: 1 });
  const ref = findElRef(p, "el-ai1-0");
  assert("text 落到 text 轨道", ref && p.scenes[0].tracks.overlay.some((t) => t.id === ref.trackId && t.type === "text"));
  sandbox.applyOp(p, { type: "param", payload: { ref, params: { opacity: 1 } } }, { seq: 2 });
  const tEl = findEl(p, "el-ai1-0");
  assert("无关键帧 → 写基础值", tEl.params.opacity === 1 && !tEl.animations, JSON.stringify(tEl.params));
  sandbox.applyOp(p, { type: "keyframe-upsert", payload: { ref, path: "opacity", atSec: 0, value: 0 } }, { seq: 3 });
  const tEl2 = findEl(p, "el-ai1-0");
  assert("upsert 建关键帧", tEl2.animations && tEl2.animations.opacity && tEl2.animations.opacity.keys.length === 1);
  sandbox.applyOp(p, { type: "param", payload: { ref, params: { opacity: 1 }, atSec: 3 } }, { seq: 4 });
  const tEl3 = findEl(p, "el-ai1-0");
  assert("有关键帧 → 落关键帧", tEl3.animations.opacity.keys.length === 2 && tEl3.params.opacity === 1, JSON.stringify(tEl3.animations.opacity));
  const det = sandbox.elementDetail(p, ref);
  assert("element.get 动画摘要", det.animations.opacity && det.animations.opacity.keyCount === 2);
}

console.log("\n== split / trim / delete ==");
{
  const p = defaultProject();
  sandbox.applyOp(p, { type: "insert", payload: { element: { type: "video", name: "V", mediaId: "a1", startSec: 0, durationSec: 4 } } }, { seq: 1 });
  const ref = { trackId: p.scenes[0].tracks.main.id, elementId: "el-ai1-0" };
  const sp = sandbox.applyOp(p, { type: "split", payload: { ref, atSec: 1.5 } }, { seq: 2 });
  const els = p.scenes[0].tracks.main.elements;
  assert("split 成两段", els.length === 2, JSON.stringify(els.map((e) => e.duration)));
  assert("左段 1.5s 右段 2.5s", sandbox.secOf(els[0].duration) === 1.5 && sandbox.secOf(els[1].duration) === 2.5);
  assert("split 确定性 id", sp.refs[0].elementId === "el-ai2-r1" && sp.refs[1].elementId === "el-ai2-r2");
  sandbox.applyOp(p, { type: "trim", payload: { ref: sp.refs[0], startSec: 1, durationSec: 1, ripple: true } }, { seq: 3 });
  assert("trim 位移", sandbox.secOf(els[0].startTime) === 1);
  assert("ripple 后段平移", sandbox.secOf(els[1].startTime) === 2);
  sandbox.applyOp(p, { type: "delete", payload: { refs: [sp.refs[0]] } }, { seq: 4 });
  assert("delete 移除", p.scenes[0].tracks.main.elements.length === 1);
}

console.log("\n== 统一 op 日志：command → undo → redo → conflict ==");
{
  const p = defaultProject();
  sandbox.ensureSchema(mockCtx, "p1");
  // 直接落库初始项目
  mockCtx.sqlite.execute(
    "insert into editor_projects (project_id, project_json, registered_assets_json, version, updated_at) values (?, ?, ?, ?, ?)",
    ["p1", JSON.stringify(p), "[]", 1, new Date().toISOString()],
  );
  const c1 = cmd({ type: "insert", payload: { element: { type: "video", name: "A", mediaId: "a1", startSec: 0, durationSec: 2 } } });
  assert("command insert ok + version 2", c1.ok && c1.version === 2, JSON.stringify(c1));
  assert("insert 确定性 id", c1.result.element.elementId === "el-ai1-0");
  const c2 = cmd({ type: "param", payload: { ref: c1.result.element, params: { opacity: 0.5 } } });
  assert("command param ok + version 3", c2.ok && c2.version === 3);
  // baseVersion 冲突
  const bad = cmd({ type: "delete", payload: { refs: [c1.result.element] }, baseVersion: 2 });
  assert("过期 baseVersion → conflict", bad.ok === false && bad.conflict === true && bad.currentVersion === 3, JSON.stringify(bad));
  // 无 conflict 写
  const okDelete = cmd({ type: "delete", payload: { refs: [c1.result.element] } });
  assert("正确 baseVersion → 成功", okDelete.ok && okDelete.version === 4, JSON.stringify(okDelete));
  // undo
  const u1 = sandbox.undoLast(mockCtx, "p1");
  assert("undo 恢复元素 + version 5", u1.ok && u1.version === 5 && u1.undidSeq === 3, JSON.stringify(u1));
  // 读取当前 project_json
  const proj = readStoredProject();
  assert("undo 后元素仍在（撤销的是 delete）", sandbox.condensedTimeline(proj).clips.length === 1);
  // redo
  const r1 = sandbox.redoNext(mockCtx, "p1");
  assert("redo 重放 delete + version 6", r1.ok && r1.version === 6, JSON.stringify(r1));
  const proj2 = readStoredProject();
  assert("redo 后元素删除", sandbox.condensedTimeline(proj2).clips.length === 0);
}
function readStoredProject() {
  const rows = mockCtx.sqlite.query("select project_json from editor_projects where project_id = ?", ["p1"]);
  return JSON.parse(rows[0].project_json);
}

console.log("\n== aiLock ==");
{
  const lock = sandbox.readLock(mockCtx, "p1");
  assert("初始无锁", lock === null);
  sandbox.writeLock(mockCtx, "p1", "agent");
  const l2 = sandbox.readLock(mockCtx, "p1");
  assert("写锁成功", l2 && l2.owner === "agent");
  sandbox.clearLock(mockCtx, "p1");
  assert("清锁成功", sandbox.readLock(mockCtx, "p1") === null);
}

console.log("\n" + (failures === 0 ? "ALL PASS" : failures + " FAILURES"));
process.exit(failures === 0 ? 0 : 1);
