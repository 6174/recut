/**
 * [INPUT]: 单文件 TS/TSX 组件源码（仅允许外部 import @recut/runtime）+ 可选 SDK d.ts 目录
 * [OUTPUT]: ESM bundle（external @recut/runtime，jsxImportSource=@recut/runtime）+ 内容寻址 hash；
 *           确定性静态扫描（禁墙钟/随机源）；可选 tsc 类型检查
 * [POS]: 服务端 AI 组件构建工具链（component.define 调用）；结果以 JSON 写 stdout
 * [PROTOCOL]: 变更时更新此头部
 *
 * 用法: node component-build.js <sourceFile> <outFile> [sdkDtsDir]
 */

const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const crypto = require("node:crypto");

function resolveFrom(pkg, fromDir) {
	return require.resolve(pkg, { paths: [fromDir] });
}

function fail(payload) {
	console.log(JSON.stringify(payload));
	process.exit(1);
}

/** 静态扫描：拒绝墙钟/随机源，且只允许 @recut/runtime 外部 import（单文件组件白名单）。 */
function staticScan(source) {
	const issues = [];
	const FORBIDDEN = [
		"Math.random",
		"Date.now",
		"performance.now",
		"new Date(",
		"setTimeout(",
		"setInterval(",
		"requestAnimationFrame",
		"crypto.random",
	];
	for (const token of FORBIDDEN) {
		if (source.includes(token)) issues.push(token);
	}
	// 白名单 import：只允许 @recut/runtime（及其 /jsx-runtime），其余一律拒绝。
	const ALLOWED = ["@recut/runtime"];
	const importRe = /(?:^|\n)\s*import\s+(?:[^"']*?\s+from\s+)?["']([^"']+)["']/g;
	let match;
	while ((match = importRe.exec(source)) !== null) {
		const specifier = match[1];
		if (!ALLOWED.includes(specifier) && !specifier.startsWith("@recut/runtime/")) {
			issues.push(`非法 import: ${specifier}`);
		}
	}
	return issues;
}

async function main() {
	const [sourcePath, outPath, sdkDtsDir] = process.argv.slice(2);
	if (!sourcePath || !outPath) {
		fail({ ok: false, type: "usage", error: "用法: node component-build.js <sourceFile> <outFile> [sdkDtsDir]" });
	}

	let source;
	try {
		source = fs.readFileSync(sourcePath, "utf8");
	} catch (error) {
		fail({ ok: false, type: "read", error: String((error && error.message) || error) });
	}

	const issues = staticScan(source);
	if (issues.length > 0) {
		fail({ ok: false, type: "determinism", issues });
	}

	let esbuild;
	try {
		esbuild = require(resolveFrom("esbuild", path.join(__dirname, "..", "ui")));
	} catch (error) {
		fail({ ok: false, type: "esbuild", error: "esbuild 不可用: " + String((error && error.message) || error) });
	}

	let result;
	try {
		result = await esbuild.transform(source, {
			loader: "tsx",
			jsx: "automatic",
			jsxImportSource: "@recut/runtime",
			format: "esm",
			target: "chrome130",
			sourcemap: "inline",
		});
	} catch (error) {
		fail({ ok: false, type: "compile", error: String((error && error.message) || error) });
	}

	const bundle = result.code;
	const bundleHash = crypto.createHash("sha256").update(bundle).digest("hex");

	let typeErrors = [];
	if (sdkDtsDir) {
		typeErrors = runTypecheck({ sourcePath, sdkDtsDir });
		if (typeErrors.length > 0) {
			fail({ ok: false, type: "typecheck", errors: typeErrors });
		}
	}

	fs.writeFileSync(outPath, bundle, "utf8");
	console.log(
		JSON.stringify({ ok: true, bundleHash, bytes: Buffer.byteLength(bundle) }),
	);
}

function runTypecheck({ sourcePath, sdkDtsDir }) {
	try {
		const tsc = require(resolveFrom("typescript", path.join(__dirname, "..", "ui")));
		const dtsPath = path.join(sdkDtsDir, "runtime.d.ts");
		if (!fs.existsSync(dtsPath)) {
			return [`SDK d.ts 不存在: ${dtsPath}`];
		}
		const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "recut-comp-"));
		const localDts = path.join(tmpDir, "runtime.d.ts");
		fs.copyFileSync(dtsPath, localDts);
		const program = tsc.createProgram({
			rootNames: [sourcePath, localDts],
			options: {
				noEmit: true,
				strict: true,
				jsx: tsc.JsxEmit.ReactJSX,
				jsxImportSource: "@recut/runtime",
				module: tsc.ModuleKind.ESNext,
				moduleResolution: tsc.ModuleResolutionKind.Bundler,
				target: tsc.ScriptTarget.ES2022,
				lib: ["lib.dom.d.ts", "lib.es2022.d.ts"],
				skipLibCheck: true,
				types: [],
			},
		});
		const diagnostics = tsc.getPreEmitDiagnostics(program);
		return diagnostics
			.filter((d) => d.file && !d.file.fileName.endsWith("runtime.d.ts"))
			.map((d) => {
				const pos = d.file && d.start != null ? d.file.getLineAndCharacterOfPosition(d.start) : null;
				const line = pos ? pos.line + 1 : "?";
				const col = pos ? pos.character + 1 : "?";
				return `(${line},${col}) TS${d.code}: ${tsc.flattenDiagnosticMessageText(d.messageText, "\n")}`;
			});
	} catch (error) {
		return [`typecheck 不可用: ${String((error && error.message) || error)}`];
	}
}

main().catch((error) => {
	fail({ ok: false, error: String((error && error.stack) || error) });
});
