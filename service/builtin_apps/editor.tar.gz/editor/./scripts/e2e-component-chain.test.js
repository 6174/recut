/**
 * [INPUT]: 依赖真实 apps/editor/background.js（component.define/verify/list/source/resolve）与
 *          scripts/component-build.js（esbuild+tsc+确定性扫描），经 ctx 桩驱动
 * [OUTPUT]: 自动跑通 AI 组件核心链路：define→build→verify(head 跟随)→resolve→迭代→失败防护
 * [POS]: AI 临时组件机制的 background 侧回归测试
 * [PROTOCOL]: 变更时更新此头部
 *
 * 运行: node scripts/e2e-component-chain.test.js
 */
const { spawnSync } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const assert = require("node:assert/strict");

const { DatabaseSync } = require("node:sqlite");
const APP_ROOT = path.join(__dirname, "..");

const handlers = {};
global.recut = {
	operation: {
		register(name, handler) {
			handlers[name] = handler;
		},
	},
};
require(path.join(APP_ROOT, "background.js"));

const filesRoot = fs.mkdtempSync(path.join(os.tmpdir(), "recut-files-"));
const db = new DatabaseSync(":memory:");

const ctx = {
	project: { id: "proj-e2e" },
	paths: { appRoot: APP_ROOT },
	sqlite: {
		execute(sql, params = []) {
			if (params.length > 0 && sql.includes("?")) {
				db.prepare(sql).run(...params);
			} else {
				db.exec(sql);
			}
		},
		query(sql, params = []) {
			return params.length > 0 ? db.prepare(sql).all(...params) : db.prepare(sql).all();
		},
	},
	files: {
		writeText(p, content) {
			const full = path.join(filesRoot, p);
			fs.mkdirSync(path.dirname(full), { recursive: true });
			fs.writeFileSync(full, content);
		},
		readText(p) {
			return fs.readFileSync(path.join(filesRoot, p), "utf8");
		},
	},
	shell: {
		exec({ command, args, cwd }) {
			const base = cwd === "files" ? filesRoot : process.cwd();
			const result = spawnSync(command, args, { cwd: base, encoding: "utf8" });
			return { stdout: result.stdout || "", code: result.status ?? -1 };
		},
	},
};

const call = (name, input) => handlers[name](input, ctx);

const HTML_SOURCE = `import { str } from "@recut/runtime";
import type { ComponentRenderContext } from "@recut/runtime";

export default {
  surface: "html",
  name: "Countdown",
  keywords: ["countdown", "倒计时"],
  inputs: [
    { key: "color", type: "color", default: "#0ea5e9", label: "主色" },
  ],
  render(ctx: ComponentRenderContext) {
    const { params, progress, anim } = ctx;
    const color = str(params.color, "#0ea5e9");
    const n = Math.ceil((1 - progress) * 5);
    const scale = 1 + anim.pulse(progress, { speed: 2 }) * 0.1;
    return \`<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-family:sans-serif;color:\${color};font-weight:800;font-size:120px;transform:scale(\${scale.toFixed(3)});">\${n}</div>\`;
  },
};
`;

const R3F_SOURCE = `import { str } from "@recut/runtime";
import type { ComponentRenderContext } from "@recut/runtime";

export default {
  surface: "r3f",
  name: "Pulse Cube",
  keywords: ["cube", "方块"],
  inputs: [
    { key: "color", type: "color", default: "#ff2244", label: "主色" },
  ],
  render(ctx: ComponentRenderContext) {
    const { params, progress, anim } = ctx;
    const color = str(params.color, "#ff2244");
    const size = 100 + anim.pulse(progress) * 40;
    return <mesh><boxGeometry args={[size, size, size]} /><meshBasicMaterial color={color} /></mesh>;
  },
};
`;

const BAD_SOURCE = `import type { ComponentRenderContext } from "@recut/runtime";
export default {
  surface: "react",
  name: "Bad",
  inputs: [],
  render(ctx: ComponentRenderContext) {
    const r = Math.random();
    return <div>{r}</div>;
  },
};
`;

const ILLEGAL_IMPORT_SOURCE = `import { str } from "lodash";
export default {
  surface: "html",
  name: "Illegal",
  inputs: [],
  render() {
    return str("x");
  },
};
`;

let failures = 0;
function check(name, fn) {
	try {
		fn();
		console.log(`  ok: ${name}`);
	} catch (error) {
		failures += 1;
		console.error(`  FAIL: ${name}\n    ${error && error.message}`);
	}
}

// ---- 1. define（新建）→ draft ----
const defined = call("component.define", { name: "Countdown", surface: "html", keywords: ["countdown"], inputs: [{ key: "color", type: "color", default: "#0ea5e9", label: "主色" }], source: HTML_SOURCE });
check("define 新建返回 draft", () => {
	assert.equal(defined.status, "draft");
	assert.match(defined.componentId, /^ai-/);
	assert.equal(defined.version, 1);
	assert.equal(defined.versionId, `${defined.componentId}@1`);
});

// ---- 2. resolve 精确版本 → bundle ----
const resolvedV1 = call("component.resolve", { versionId: defined.versionId });
check("resolve 精确版本返回编译产物", () => {
	assert.equal(resolvedV1.components.length, 1);
	assert.equal(resolvedV1.components[0].surface, "html");
	assert.ok(resolvedV1.components[0].bundle.length > 200);
	assert.equal(resolvedV1.components[0].bundleHash.length, 64);
	assert.ok(resolvedV1.components[0].bundle.includes('from "@recut/runtime"'));
	assert.deepEqual(resolvedV1.components[0].inputs.map((i) => i.key), ["color"]);
});

// ---- 3. verify ok → verified + head ----
call("component.verify", { versionId: defined.versionId, report: { ok: true, checks: [{ name: "smoke", pass: true }] } });
const resolvedHead = call("component.resolve", { ids: [defined.componentId] });
check("verify 通过后 head 生效", () => {
	assert.equal(resolvedHead.components[0].status, "verified");
	assert.equal(resolvedHead.components[0].versionId, defined.versionId);
	assert.equal(resolvedHead.components[0].bundleHash, resolvedV1.components[0].bundleHash);
});

// ---- 4. 迭代：同 componentId 新版本，head 不跟随未验证版本 ----
const v2 = call("component.define", { componentId: defined.componentId, surface: "html", source: HTML_SOURCE.replace("#0ea5e9", "#ff0000") });
check("迭代产生新版本 draft", () => {
	assert.equal(v2.version, 2);
	assert.equal(v2.status, "draft");
});
const headAfterV2 = call("component.resolve", { ids: [defined.componentId] });
check("未验证版本不覆盖 head", () => {
	assert.equal(headAfterV2.components[0].versionId, defined.versionId);
});

// ---- 5. 验证 @2 → head 迁移 ----
call("component.verify", { versionId: v2.versionId, report: { ok: true } });
const headAfterV2Verified = call("component.resolve", { ids: [defined.componentId] });
check("验证 @2 后 head 迁移", () => {
	assert.equal(headAfterV2Verified.components[0].versionId, v2.versionId);
});

// ---- 6. 失败防护：Math.random 被确定性扫描拦截 ----
const bad = call("component.define", { surface: "react", source: BAD_SOURCE });
check("墙钟/随机源被构建拦截", () => {
	assert.equal(bad.status, "failed");
	assert.equal(bad.buildError.type, "determinism");
	assert.deepEqual(bad.buildError.issues, ["Math.random"]);
});

// ---- 6b. 白名单：非 @recut/runtime 的外部 import 被拒绝 ----
const illegal = call("component.define", { surface: "html", source: ILLEGAL_IMPORT_SOURCE });
check("非法外部 import 被拒绝", () => {
	assert.equal(illegal.status, "failed");
	assert.ok(illegal.buildError.issues.some((i) => i.includes("非法 import")));
});

// ---- 7. source 可读（AI 二次调整输入） ----
const src = call("component.source", { componentId: defined.componentId });
check("component.source 返回最新源码", () => {
	assert.equal(src.versionId, v2.versionId);
	assert.ok(src.source.includes("#ff0000"));
});

// ---- 8. list ----
const list = call("component.list", {});
check("component.list 汇总", () => {
	const comp = list.components.find((c) => c.componentId === defined.componentId);
	assert.ok(comp);
	assert.equal(comp.status, "verified");
	assert.equal(comp.version, 2);
	assert.equal(comp.surface, "html");
});

// ---- 9. r3f surface 编译含 jsx-runtime import ----
const r3f = call("component.define", { surface: "r3f", source: R3F_SOURCE });
check("r3f 组件编译通过", () => {
	assert.equal(r3f.status, "draft");
	const r = call("component.resolve", { versionId: r3f.versionId });
	assert.ok(r.components[0].bundle.includes('"@recut/runtime/jsx-runtime"'));
});

// ---- 10. verify failed 不覆盖 head ----
call("component.verify", { versionId: r3f.versionId, report: { ok: false, error: "render threw" } });
check("verify 失败置 failed 且 head 不动", () => {
	const st = call("component.verify", { versionId: r3f.versionId });
	assert.equal(st.status, "failed");
	assert.equal(st.report.ok, false);
	const stillHead = call("component.resolve", { ids: [defined.componentId] });
	assert.equal(stillHead.components[0].versionId, v2.versionId);
});

console.log(failures === 0 ? "\n✅ E2E background 链路全部通过" : `\n❌ ${failures} 项失败`);
process.exit(failures === 0 ? 0 : 1);
