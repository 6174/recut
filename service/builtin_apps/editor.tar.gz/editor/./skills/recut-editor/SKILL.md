# recut-editor · 剪辑器

Recut 的核心时间线剪辑器（CapCut 风格）。把素材库 assets、AI 短片与程序化视频编排成最终成片。

## 定位

- 编辑器是 **project 型内置 App**（`recut.editor`）。项目桌面即编辑器 iframe。
- **时间线永远是 2D 编辑模型**，3D 只作为特效层（R3F 子场景 → 纹理 → 2D 合成栈）。
- 素材只经 **assetId** 引用；绝不读别的 App 的库。预览用 `mediaContentURL(assetId)`，导出用 `ctx.media.materialize`。

## 工作流

1. **先调用 `workflow.context`**：返回项目设置、时间线摘要（elements/tracks）、已登记 assets、`allowedActions` 与 `paths`。返回值覆盖聊天记忆。
2. **新建项目**：`project.create`（可带 settings：fps/canvasSize/background 与 materialAssetIds）。
3. **找素材**：用 `recut.media.list_assets` 发现真实 assetId（image/video/audio/transcript/reference）。
4. **编辑时间线**：对 UI 用户，编辑在 iframe 内完成（放置/裁剪/关键帧），编辑器自动 `project.save` + `timeline.assets` 登记。对 Agent：
   - 批量建稿：`film.package.import` 把 AI 短片包（recut.ai-short-film.package@1）自动铺成时间线草稿。
   - 程序化编辑：直接 `project.load` 读 TProject，按 `TProject` JSON 结构构造元素后 `project.save`（元素字段：id/name/type/startTime/duration/trimStart/trimEnd/params/animations/effects/masks；`startTime`/`duration`/`trimStart`/`trimEnd` 为整数 tick，120000 ticks/秒）。
5. **登记素材**：每次保存时间线后调用 `timeline.assets`（覆盖式）；漏登记的素材在导出里会是空。
6. **导出**：UI 在 iframe 内用与预览同一帧循环编码 MP4，再 `export.start` → `export.progress` → `export.complete`（base64 字节）。完成时平台自动 `importFile` 为 video Asset 并设为项目封面。

## 时间线数据结构（TProject 摘要）

- `metadata`：id/name/thumbnail/duration(ticks)/createdAt/updatedAt
- `scenes[]`：多场景；每场景 `tracks: { overlay[], main(必须存在，从 0 开始), audio[] }`
- `track.elements[]`：7 种元素（video/image/text/sticker/graphic/effect/audio），共享 `BaseTimelineElement`（startTime/duration/trimStart/trimEnd/params/animations）
- `settings`：`{ fps: {numerator,denominator}, canvasSize, background }`
- `params`：`Record<string, number|string|boolean>`；transform/opacity/blend 等均存于此（如 `transform.positionX`、`opacity`）
- `animations`：`Record<propertyPath, ChannelData>`，路径与 param key 同构；关键帧插值 linear/hold/bezier

## 禁止

- 不要直接构造被 UI 私有格式篡改的字段；元素必填 `id`（`el-` 前缀）、`type`、`startTime`、`duration`、`params`。
- 不要绕过 `project.save` 写 `ctx.sqlite` 之外的状态。
- 不要在 `film.package.import` 之外臆造素材；所有 mediaId 必须是真实 assetId。
- 不要把动画写成"墙钟推进"（rAF/spring）；关键帧必须可寻址（f(t)），否则导出不精确。
