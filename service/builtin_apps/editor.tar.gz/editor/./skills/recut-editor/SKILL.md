---
name: recut-editor
description: Recut 核心时间线剪辑器（CapCut 风格）。AI 以「导演」身份通过 recut.editor.* MCP 工具完全接管编辑：读 condensed 时间线、以统一 op 日志可 undo 地增删/裁剪/变速/打关键帧/加效果与蒙版/放 AI 临时组件、视觉验证、双模导出。素材只经 assetId 引用。
references: data-model.md, timeline-workflow.md, params.md, keyframes.md, components.md, component-authoring.md, directing.md, shot-library.md, music-beat-sync.md, captions.md, preview-export.md
---

# recut-editor · 剪辑器（AI 全权编辑）

> 这是编辑契约。项目当前状态、version、aiLock 与可用动作以 `workflow.context` 为准；工具与 op 语义见 `references/*`。

## 定位

- 编辑器是 **project 型内置 App**（`recut.editor`）。项目桌面即编辑器 iframe。
- **AI 通过 MCP 工具驱动，与 UI 共用同一套可 undo 的写引擎**（统一 op 日志，`editor_command_log`）。AI 不需要也无法手写 TProject JSON。
- **时间线永远是 2D 编辑模型**，3D 只作为特效层；素材只经 **assetId** 引用，绝不臆造 assetId。

## 心智模型

```text
AI = 导演
MCP = 可 undo 的剪辑台（recut.editor.*）

timeline.read / element.get / project.get / timeline.validate   → 只看
timeline.command { op }                                          → 唯一写入口（统一日志，可 undo）
history.undo / history.redo                                      → 回退 / 重做（AI 与 UI 同一权威）
project.lock / project.unlock                                    → AI 独占会话（多步编辑）
preview.frame / component.verify                                 → 视觉 / 结构化验证
export.start(mode) / recut.job.*                                 → 导出
```

## 工作流 loop

每次编辑会话按此循环，任何一步不满意就 `history.undo`：

1. **`workflow.context`**：读 stage、settings、version、aiLock、allowedActions、paths。返回值覆盖聊天记忆。
2. **读**：`timeline.read`（condensed 摘要，token 高效）→ 需要细节时 `element.get` / `project.get`。
3. **计划**：明确目标镜头/字幕/音频/组件，确定要插入/删除/裁剪/变速/关键帧的元素与时间（秒）。
4. **独占会话**（多步编辑时）：`project.lock` → 编辑 → `project.unlock`。
5. **变更**：`timeline.command` 逐个 op（见 `references/timeline-workflow.md` 的 op 目录）。每 op 返回 `{ version, seq, result }`。
6. **验证**：`timeline.validate` 为零违反（asset-exists/track-type/overlap/out-of-range/component-def/param-valid）；画面用 `preview.frame` 渲染关键帧时刻自检。
7. **导出**：`export.start({ mode: "headless" })` → `recut.job.wait` / `export.status` 观察 → 产物成为 video Asset 并设封面。

## 工具矩阵（recut.editor.*）

| 域 | 工具 | 说明 |
|---|---|---|
| 读 | `workflow.context` / `timeline.read` / `element.get` / `project.get` | condensed 摘要 / 单元素全量 / 项目设置与锁 |
| 校验 | `timeline.validate` | 不变式，export 前零违反 |
| 写 | `timeline.command {op}` | 唯一写入口，op 见 references/timeline-workflow.md |
| 历史 | `history.undo` / `history.redo` | 统一日志回退/重做 |
| 会话 | `project.lock` / `project.unlock` | AI 独占；锁内 iframe 只读 |
| 素材 | `timeline.assets` / 平台 `recut.media.list_assets` | 登记 / 发现 assetId |
| AI 组件 | `component.define` / `component.verify` / `component.list` / `component.source` | 代码即素材（references/components.md） |
| 导入 | `film.package.import` | AI 短片交接包铺稿 |
| 导出 | `export.start(mode)` / `export.list` | headless / ui 双模 |

## 门禁

- 每次 `timeline.command` 携带准确的 `baseVersion`（`workflow.context` 的 version）；过期会返回 `{ conflict, currentVersion, opsSince }` → 重读后重放。
- `timeline.validate` 必须零违反后才导出。
- 所有 `mediaId`/`assetId`/`sourceUrl` 必须来自 `recut.media.list_assets` 或 `film.package.import` 的包；`type:"component"` 的 `componentId` 必须来自 `component.list`。
- 时间一律用**秒**（浮点）；读取双返回 `*Sec`。

## 禁止

- 不手写或臆造 TProject JSON（`project.load`/`project.save` 是 api-only，MCP 不可达；写编辑一律走 `timeline.command`）。
- 不把动画写成"墙钟推进"（rAF/spring）；关键帧必须可寻址 `{path, atSec, value}`，否则导出不精确。
- 不臆造 assetId / componentId / trackId / elementId——全部来自读取工具返回值。
- 不在 `timeline.command` 之外直接改 sqlite 或 files。

## 读取工具语义

`timeline.read` / `element.get` / `project.get` / `timeline.validate` 的字段定义、op 目录与参考实现见：
- `references/data-model.md`（ElementRef、CondensedClip、秒↔tick、轨道与 7+1 元素、版本/锁）
- `references/timeline-workflow.md`（op 目录 + 编排模式）
- `references/params.md`（params 键与默认值）
- `references/keyframes.md`（D1 提交策略）
- `references/components.md`（AI 临时组件 · 工具与 SDK 契约）
- `references/component-authoring.md`（AI 临时组件 · 创作指南：surface 决策、参数设计、确定性动画、三 surface 示例、验证迭代）
- `references/preview-export.md`（视觉验收与导出）

## 导演参考（做不同类型的视频）

- **先定动效嗓音**：`references/directing.md` —— 品牌能量/调性 → 时长与 transform/opacity 参数预设；5 秒节拍、一镜一动作、开场三秒钩子、落定呼吸；镜头动词 → timeline 配方；确定性铁律与导演自检清单。
- **镜头配方库**：`references/shot-library.md` —— 开场/转场/运镜/节奏/注意力 10 个配方，每个是一串可直接落地的 `timeline.command` op（insert / keyframe-upsert / trim / split）。
- **卡点**：`references/music-beat-sync.md` —— BPM 分析 → 拍号秒表 `beatT(n)` → 镜头边界与关键帧全部锚到拍；渲后回测误差 ≤3 帧。
- **字幕**：`references/captions.md` —— text 元素字幕（≥40px、无底框、下三分之一）。
- **自定义组件素材**：`references/component-authoring.md` —— 时间线 op 表达不了的"代码视觉"（数据驱动、3D/shader）用 `component.define` 写组件；先想清楚再选 surface。

> 与 remotion-studio 的核心差异：**本编辑器是时间线 + AI 协作**（所有表达落成 op 与关键帧，可 undo、可预览、可验证），**Remotion 是完全基于代码**（改写 composition）。导演层的创意知识同源，但实现介质不同。
