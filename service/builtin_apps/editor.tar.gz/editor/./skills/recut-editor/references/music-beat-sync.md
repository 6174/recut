# music-beat-sync — 卡点方法论（recut.editor）

> 与 remotion-studio `music-beat-sync.md` 同源，但**切点/关键帧直接落到时间线 op**：用 `split`/`trim` 让镜头边界精确落在拍号上，用 `keyframe-upsert` 让动效锚到拍。目标：成片切点误差 ≤3 帧（感知阈值）。

## 0. 何时启用

- 用户已指定强节奏 BGM → 先分析节奏，再让每个切点/动效锚到拍号。
- 未指定 BGM → 时间线按内容节奏排，不强行卡点。

## 1. 节拍网格测定（不信 tempo 标量，拟合 beat 序列）

对 BGM 跑一次性脚本（librosa 不在系统 python 时用 `uv run --with librosa --with scipy --python 3.11`）：

```python
import numpy as np, librosa
y, sr = librosa.load("bgm.mp3", sr=None, mono=True)
tempo, beats = librosa.beat.beat_track(y=y, sr=sr, tightness=400, units="time")
# 对 beat 序列最小二乘等距网格拟合：t_i = t0 + i*T
i = np.arange(len(beats))
A = np.vstack([i, np.ones_like(i)]).T
(T, t0), *_ = np.linalg.lstsq(A, beats, rcond=None)
bpm = 60.0 / T
residual = beats - (t0 + i * T)
print(f"BPM={bpm:.2f}  t0={t0:.4f}s  T={T:.5f}s  残差±{np.abs(residual).max()*1000:.0f}ms")
```

验收：残差 ≤ ±15ms（半帧内）→ 网格可信；残差大 → 变速段分段拟合。

## 2. 产出拍号秒表 beatT(n) 与结构

把 `t0`（拍 0 秒位）与 `T`（拍长）写进你的时间线换算表：

```text
beatT(n) = t0 + n * T            # 拍号 → 秒（编辑器一律用秒）
镜头边界 = beatT(整数拍)，如 [0, beatT(8), beatT(16), ...]
```

- **音乐结构表**：能量从第几拍起满、breakdown/静默在第几拍——分镜能量曲线贴着它排（breakdown 处放品牌呼吸位是天然结构）。
- **最强 hit 拍号**：全片 2–3 个最大 slam（开题/高潮/收尾）钉在整数拍上。
- 易错：强鼓点曲重音几乎总在整数拍；半拍钉点必须有能量数据支持，不凭听感。

## 3. 用拍号排时间线（split/trim 落拍）

```text
# 120 BPM → T=0.5s，4 拍一镜 = 2s
insert image A { startSec: beatT(0),  durationSec: 2 }
insert image B { startSec: beatT(4),  durationSec: 2 }
insert image C { startSec: beatT(8),  durationSec: 2 }
# 需要精确切点时：先放整段，再 split { ref, atSec: beatT(n) }，删多余侧
```

设计规矩：
- 镜头时长以拍为单位（4/8 拍一镜）；加速段可用半拍/四分之一拍阶梯（如收敛逼近 `beatT(48) → beatT(49.5) → beatT(50.5)`）。
- 每拍一动作的步进类镜头（清单逐项、数字滚动）直接把动作时间设为 `beatT(n)` + 组件 `anim.pulse(progress)`。
- BGM 鼓点已密时动效克制：大 slam 只给 2–3 处，其余让位给鼓。

## 4. 渲后回测（闭环，必做）

```bash
ffmpeg -i export.mp4 -vn -acodec pcm_s16le /tmp/render-audio.wav
```

对渲出音轨重跑第 1 步拟合（从视频里量，连编码/对齐偏移一起验），逐一对比设计切点秒 vs 最近测得拍的秒。

| 判定 | 误差 |
|---|---|
| 合格 | ≤3 帧（感知阈值） |
| 理想 | ≤1.5 帧 |
| 必修 | >3 帧的任何切点 |

超标的切点回第 3 步改 `atSec`/`startSec`，重渲再测直到全表合格。

## 5. 工具备忘

- 只有人声/复杂编曲会漂：先用 `librosa.effects.hpss` 分离打击成分再测。
- 变速曲（DJ 转场/accelerando）：按能量段分段拟合，各段各自 `t0`/`T`。
- 卡点关键帧：`keyframe-upsert { ref, path:"opacity", atSec: beatT(n), value: 0 }` 等，一律用 `beatT(n)` 表达，换曲时只改 `t0`/`T` 两常量全片重排。
