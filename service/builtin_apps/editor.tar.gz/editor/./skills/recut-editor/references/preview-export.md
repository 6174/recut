# 预览与导出（recut.editor）

## 视觉验证：preview.frame

- 在 `t` 处渲染当前 doc 帧为 PNG 图片 Asset，返回 `assetId`（AI 用平台读图能力自检构图/文字/蒙版/关键帧插值）。
- 在 `timeline.validate` 零违反后、`export.start` 前，对关键时间点（开场、转场、结尾）各渲一帧验收。
- 确定性：同 doc + 同 t 两次渲染像素一致（Preview==Export）。

## 导出

| 模式 | 说明 |
|---|---|
| `mode:"headless"` | 后台无头 Chromium 跑共享 Visual Runtime + ffmpeg 编码；返回平台 jobId，用 `recut.job.wait` / `recut.job.status` 观察终态 |
| `mode:"ui"` | 编辑器 iframe 用与预览同一帧循环编码 MP4（UI 用户路径） |

- 完成时平台自动 `importFile` 为 video Asset 并设为项目封面。
- `export.list` 读取历史导出（含产物 assetId 与设置）。
- 导出一致性：headless 与 ui 共用同一 Visual Runtime + 确定性契约，逐帧一致。

## 自动首帧封面（UI 驱动，非 media Asset）

- 编辑器时间线内容变化后，UI 在空闲约 1.5s 渲染首帧（t=0，与预览/导出同契约），
  经 `cover.update` 把 PNG 写入项目文件根 `covers/cover.png` 并登记为 file 封面。
- 封面不产生 media Asset（不污染素材库）；两次推送至少间隔 30s；帧未变（hash 相同）则跳过。
- 平台经 `GET /v1/projects/{id}/cover` 直接服务该文件，web 项目卡与详情页实时跟随首帧。
- 导出成片仍走 asset 封面（video Asset），与首帧 file 封面共存（以最后更新者为准）。

## 导出前 checklist

1. `timeline.validate` → `ok: true`（零 violations）
2. 所有 `mediaId`/`componentId` 已登记 / 已 verify（`timeline.assets` 覆盖式登记）
3. 关键帧/动画已预览确认
4. `project.lock` 已释放（如有）
5. `export.start({ mode: "headless", width, height, fps })` → 观察 job → 产物 assetId 落库并设封面
