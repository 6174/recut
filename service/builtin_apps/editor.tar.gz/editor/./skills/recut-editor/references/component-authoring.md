# 自定义组件创作指南（recut.editor）

> 代码即素材。**本文件是"怎么写出好组件"的创作指南**；工具/SDK 契约见 `components.md`。
> 组件 = 项目内的一段可验证代码素材：`component.define` 提交源码 → 构建（esbuild+tsc+确定性扫描）→ `component.verify` 渲染验证 → verified 成为 head → 时间线所有使用点立即生效。

## 一、什么时候用组件，而不是时间线 op

| 需求 | 用 |
|---|---|
| 摆布已有素材（裁剪/位移/变速/淡入） | 时间线 op（`insert`/`trim`/`param`/`keyframe-upsert`） |
| 逐元素独立动画、蒙版、9 种图形 | 时间线 op + 内置 graphic |
| 数据驱动的动态视觉（倒计时、数字滚动、进度条、词条强调） | **组件**（html/react） |
| 3D 对象、shader、粒子、光线感、程序化几何 | **组件**（r3f） |
| 需要随内容重复复用、参数面板驱动的视觉 | **组件** |

规则：**内置能力够用就不写组件**；组件用于时间线 op 表达不了的"代码视觉"。全片最多 1–2 个组件主角，多了读作拼盘。

## 二、选 surface

| surface | 写起来像 | 适合 | 注意 |
|---|---|---|---|
| `html` | 字符串模板 + 内联 style | 纯视觉层、无需交互状态 | 唯一入参是 render 返回的字符串；动画用 `${anim.*}` 内联值 |
| `react` | JSX 元素树 | 结构化的卡片/列表/分层视觉 | hook 可用（useState/useMemo），但**禁墙钟源** |
| `r3f` | R3F 元素树 | 3D 对象、shader、粒子、光 | v1 禁 `useFrame`；用 `anim` 驱动 mesh 属性 |

三个 surface 共享同一契约：`inputs` / `render(ctx)` / `getBaseSize` / `dispose` / 错误兜底 / 验证 harness。先写意图再选 surface，不从 API 反推。

## 三、模块形状（default export）

```ts
import { str, num } from "@recut/runtime";
import type { ComponentRenderContext } from "@recut/runtime";

export default {
  surface: "html",                       // "html" | "react" | "r3f"
  name: "Countdown",
  keywords: ["countdown", "倒计时"],      // 组件库搜索
  inputs: [                              // 参数面板即 inputs
    { key: "color", type: "color", default: "#0ea5e9", label: "主色" },
  ],
  getBaseSize: ({ params }) => ({ width: 512, height: 512 }),  // 可选；缺省 512×512
  render(ctx: ComponentRenderContext) {
    const { params, progress, localTime, anim } = ctx;
    // ... 返回 html 字符串 / JSX / R3F 元素树
  },
  dispose(instance) { /* GPU 资源释放（r3f） */ },
};
```

`ComponentRenderContext`：`params`（inputs 传入 + 时间线可覆盖）、`time`（全局秒）、`localTime`（片段内秒）、`progress`（0..1）、`anim`（确定性动画）。

## 四、参数设计（inputs = 组件的"可调旋钮"）

好的组件把**会变的**都暴露成参数，把**不变的**写死在源码：

```ts
inputs: [
  { key: "text",    type: "text",    default: "核心数字",   label: "文案" },
  { key: "color",   type: "color",   default: "#0ea5e9",   label: "主色" },
  { key: "size",    type: "number",  default: 120, min: 24, max: 360, step: 4, label: "字号" },
  { key: "accent",  type: "boolean", default: true, label: "强调模式" },
]
```

- 读取用 SDK 的 `num()`/`str()`/`bool()`（带 fallback，容忍时间线缺参）。
- `type` 合法值：`number`/`string`/`boolean`/`color`/`text`/`select`（select 带 `options`）。
- 参数名与时间线 `params` 一一对应，可打关键帧：`keyframe-upsert {ref, path:"params.<key>", atSec, value}`。
- 建 clip 时用 `component.list` 返回的 `inputs[].default` 展开成元素 params。

## 五、确定性动画（硬规则）

动画 = `t`（或 `progress`）的纯函数，**禁墙钟**（`Math.random`/`Date.now`/`performance.now`/`setTimeout`/`requestAnimationFrame`；CSS `@keyframes`/`transition` 只允许静态样式）。构建期静态扫描拒绝墙钟源。

| anim API | 用途 | 示例 |
|---|---|---|
| `anim.lerp(a, b, u, {ease})` | 数值插值 | `opacity = anim.lerp(0, 1, progress)` |
| `anim.lerpColor(c1, c2, u)` | 颜色过渡 | `anim.lerpColor("#000", color, progress)` |
| `anim.seq([[t,v],...], u)` | 关键帧取值（u 0..1） | 分段的数字/位移 |
| `anim.pulse(u, {speed, phase})` | 0..1 周期脉冲 | 呼吸 scale、闪烁 |

常用动画模式：
- **入场**：`opacity = anim.lerp(0, 1, easeIn(progress))`（`ease` 预设见 SDK）；
- **呼吸**：`scale = 1 + anim.pulse(progress, {speed: 2}) * 0.06`；
- **数字滚动/倒计时**：`Math.ceil((1 - progress) * N)`（纯算术，天然确定）；
- **关键帧分段**：`anim.seq([[0, 0], [0.5, 1], [1, 0]], progress)`。

## 六、设计准则（组件不是 UI 截图）

- **画布感知**：plane 缺省 512×512。放到 1920×1080 画布通常会被放大显示——先按 `getBaseSize` 与目标画面推算有效字高；**1080p 主信息有效字高 ≥56px、辅助 ≥32px**，缩到 480px 宽仍可读才过。
- **一镜一个动作**：组件只做一个主要动效，落定后必须 hold ≥0.5s。
- **字幕无底框**：组件不做气泡/卡片包住叙事字幕；干净高对比文字。
- 组件是"视觉素材"，不是 App UI：不做微型 tag/chip/状态栏堆信息密度。
- 配色由场景决定，不用通用渐变堆砌；保持足够对比度，不替代信息层级。

## 七、三个 surface 的完整示例（可跑）

**html —— 倒计时（纯视觉，无状态）**
```ts
import { str } from "@recut/runtime";
import type { ComponentRenderContext } from "@recut/runtime";
export default {
  surface: "html", name: "Countdown", keywords: ["countdown", "倒计时"],
  inputs: [{ key: "color", type: "color", default: "#0ea5e9", label: "主色" }],
  render(ctx: ComponentRenderContext) {
    const { params, progress, anim } = ctx;
    const color = str(params.color, "#0ea5e9");
    const n = Math.ceil((1 - progress) * 5);
    const scale = 1 + anim.pulse(progress, { speed: 2 }) * 0.1;
    return `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-family:sans-serif;color:${color};font-weight:800;font-size:120px;transform:scale(${scale.toFixed(3)});">${n}</div>`;
  },
};
```

**react —— 脉冲卡片（结构化视觉 + hook）**
```ts
import { str } from "@recut/runtime";
import type { ComponentRenderContext } from "@recut/runtime";
export default {
  surface: "react", name: "Pulse Card", keywords: ["card", "卡片"],
  inputs: [
    { key: "text", type: "text", default: "Recut", label: "文案" },
    { key: "color", type: "color", default: "#0ea5e9", label: "主色" },
  ],
  render(ctx: ComponentRenderContext) {
    const { params, progress, anim } = ctx;
    const text = str(params.text, "Recut");
    const color = str(params.color, "#0ea5e9");
    const p = anim.pulse(progress, { speed: 1.5 });
    return (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "sans-serif" }}>
        <div style={{ background: color, color: "#fff", fontWeight: 700, fontSize: 32, padding: "16px 28px", borderRadius: 16, opacity: 0.7 + 0.3 * p, transform: `translateY(${(p * -10).toFixed(2)}px)` }}>
          {text}
        </div>
      </div>
    );
  },
};
```

**r3f —— 脉冲立方体（3D mesh，禁 useFrame）**
```ts
import { str } from "@recut/runtime";
import type { ComponentRenderContext } from "@recut/runtime";
export default {
  surface: "r3f", name: "Pulse Cube", keywords: ["3d", "cube", "立方体"],
  inputs: [{ key: "color", type: "color", default: "#ff2244", label: "主色" }],
  getBaseSize: () => ({ width: 200, height: 200 }),
  render(ctx: ComponentRenderContext) {
    const { params, anim, progress } = ctx;
    const color = str(params.color, "#ff2244");
    const s = 100 + anim.pulse(progress, { speed: 2 }) * 40;
    return <mesh rotation={[0.5 * progress, 0.5 * progress, 0]} scale={[s, s, s]} position={[0, 0, 0]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color={color} />
    </mesh>;
  },
};
```

## 八、验证闭环与迭代

```text
component.define(source) → status:"draft" | "failed"(buildError 含行号)
→ component.verify(versionId)            # 无 report：轮询状态；报告 {ok, checks, frames}
   ok → verified → head 更新 → 时间线全部使用点立即生效
   坏 → failed → head 保持旧版本 → 读 component.source 修复 → 重新 define
```

- 构建失败读 `buildError`（tsc 行号 + 确定性扫描拒绝清单）修源码，**不要整段重写**。
- 每次只改目标组件的一个问题；改完重新 define → verify，直到报告全绿。
- 项目删则组件清理；无素材库、无版本 UI——head 语义让修复自动生效。

## 九、常见坑

- **双 React**：只 `import ... from "@recut/runtime"`；绝不裸 `import React` / `from "react"` / `from "three"`（会解析到不同实例）。`jsx` 由 `jsxImportSource` 自动注入。
- **墙钟源**：`Math.random`/`Date.now`/`setTimeout`/`requestAnimationFrame` 会被构建期扫描拒绝；随机需要固定种子（从 `object.id`/`componentId` 派生）。
- **texture/尺寸**：不设 `getBaseSize` 时承载面为 512×512，字号/布局按此推算；html/react 的透明留白会自动从纹理平面、命中区域与选择框裁掉，组件本身无需为选框手动包满承载面。`useCanvasTexture` 的 draw 必须是纯绘制（依赖 `params`，不依赖墙钟）。
- **perf**：组件每帧重渲；避免每帧新建大对象/纹理，重活走 `useMemo`/`useCanvasTexture`。
- **类型**：`render` 返回按 surface 放宽；`inputs.default` 必须可 JSON 且可打关键帧（number/string/boolean）。

## 十、与时间线的配合

```text
timeline.command {
  type: "insert",
  payload: { element: {
    type: "component", componentId: "<component.list 的 id>",
    startSec, durationSec,
    params: { <component.list 的 inputs default 展开> }
  } }
}
# 组件参数可打关键帧：keyframe-upsert { ref, path:"params.<key>", atSec, value }
# 验证：timeline.validate 的 component-def 校验 componentId 已 define
```
