# 字幕实践（recut.editor）

> 字幕 = text 轨上的 text 元素，与画面独立，永远最高层。适配自 remotion-studio `captions.md`，但承载从"主题组件"换成"text 元素 + params"。

## 结构

- 每个字幕片段是一个 `type:"text"` 元素，落在 text 轨（`timeline.command insert` 自动找/建 text 轨）。
- 一条一句/一个 cue：`startSec`/`durationSec` 对齐旁白；逐词高亮（karaoke）在 P1 用"每次只显示一个词、快速换 content"近似，复杂逐词效果留给组件（`component.define`）。
- 播放前先 `recut.media.list_assets` 拿 transcript 素材，用其分段时间做 cue 起点（`film.package.import` 已铺场景标题文字，可在此基础上改）。

## 参数（text 元素）

| 参数 | 说明 | 铁律 |
|---|---|---|
| `content` | 字幕文本 | 一条一个信息，不塞长句 |
| `fontSize` | 字号 | **≥40px**（1080p 有效字高）；辅助信息 ≥32px |
| `color` | 颜色 | 高对比（浅色文字 + 深底或反之），**无底框** |
| `textAlign` | 对齐 | 默认 `center` |
| `letterSpacing` / `lineHeight` | 字距/行高 | 长句开行高 ≥1.2 |
| `transform.positionY` | 位置 | 画面下三分之一（如 +260~+320，1080p） |

## 铁律

- **字幕无底框**：不用卡片/气泡/描边容器/投影块包住字幕；干净高对比文字叠在下三分之一。只有用户明确要求才例外。
- 字幕是叙事层，不与主标题争夺画面；主标题 ≥56px、字幕 ≥40px、辅助 ≥32px。
- 缩到约 480px 宽验收：字幕仍一眼读清。
- 一条字幕只承载一个新信息；信息太多先拆 cue，再放大字号，不缩小字号硬塞。

## 常见做法

```text
# 插入一条 cue（对旁白 3.2–5.8s）
timeline.command { op: { type:"insert", payload:{ element:{
  type:"text", content:"核心结论", startSec:3.2, durationSec:2.6,
  params:{ fontSize:64, color:"#FFFFFF", textAlign:"center", "transform.positionY":300 }
} } } }
# 多 cue 依次 startSec 对齐旁白分段；需要强调的词单独一条高亮色
```
