# AI 临时组件（Temp Components）

> 代码即项目内临时素材。时间线 clip `type:"component"` + `componentId`；运行时解析到**最新 verified head**。失败永不渲染，head 保持旧版本。项目作用域，删项目即清理。

## 作者分级 surface

| surface | 承载 | 典型用法 |
|---|---|---|
| `html` | 离屏 DOM → HtmlTexture plane | 模板字符串 + 内联 style |
| `react` | JSX 元素树 | hook 可用，用 `ctx.anim.*` 动画 |
| `r3f` | R3F 元素树（3D/shader） | mesh/material/light |

三个 surface 共享同一契约：`inputs`（参数面板即 inputs）、`render(ctx)`、`getBaseSize`、`dispose`、错误兜底、验证 harness。

对于 `html` / `react`，`getBaseSize` 定义的是离屏承载面的设计尺寸（未声明时为 512×512）；运行时会以纹理的非透明像素范围裁出实际平面，因此选择、命中与可见内容始终一致。不要为了让选择框变小而手写额外裁剪容器。

## SDK：`@recut/runtime`

组件**唯一允许的外部 import**（经 import map 解析到宿主共享实例，永远单 React）。导出面：

```ts
// JSX 自动运行时（jsxImportSource 指向本模块，无需 import React）
export { jsx, jsxs, Fragment }                 // 亦为 /jsx-runtime 子路径
export { useState, useMemo, useRef, useCallback, useEffect }
export * as THREE from "three"
export { useThree }                            // R3F 只读 hook（v1 禁 useFrame）
export { useCanvasTexture }
export { num, str, bool }                      // 参数读取
export const anim: {                           // 确定性动画 t→值
  lerp(a, b, u, { ease? }): number
  lerpColor(c1, c2, u): string
  seq(keys: [number, number][], u): number
  pulse(u, { speed?, phase? }): number
}
export type { ComponentRenderContext, ParamValues, ParamDefinition }
```

**硬规则：动画是 `t` 的纯函数，禁止墙钟。** CSS `@keyframes`/`transition` 只允许静态样式；一律用 `ctx.anim.*` 内联值。构建期静态扫描拒绝 `Math.random` / `Date.now` / `performance.now` / `setTimeout` / `requestAnimationFrame`。

```ts
interface ComponentRenderContext {
  world; object; params; time; localTime; progress; anim;
}
```

## 工具

| op | 说明 |
|---|---|
| `component.define` | 新建或迭代（带 `componentId` = 二次调整）。输入 `{ componentId?, name, surface, keywords, inputs, source }`；构建（esbuild+tsc+确定性扫描）成功 → `status:"draft"`；失败 → `status:"failed" + buildError`（head 不动）。读旧源码用 `component.source` |
| `component.verify` | 无 `report` → 返回当前状态供轮询；带 `report: { ok, checks, frames }`（harness 渲染结果）→ verified 并更新 head / failed |
| `component.list` | 项目内组件 + head 状态 + `inputs`（建 clip 时据此展开 params 默认值） |
| `component.source` | 读某版本源码（AI 二次调整的权威输入） |

## 放置到时间线

`type:"component"` 元素：
```text
timeline.command {
  type: "insert",
  payload: { element: { type: "component", componentId: "<来自 component.list>",
                        startSec, durationSec, params: { <inputs defaults 展开> } } }
}
```

## 验证闭环

`component.define` → `component.verify`（harness 渲染报告）→ verified 成为 head → 所有使用点立即生效。AI 经 `component.verify` 读回结构化报告自主迭代，不依赖用户肉眼。

## 常用 inputs 约定

```ts
type ParamDefinition = { key: string; label?: string; type?: "number"|"string"|"boolean"|"color"; default: number|string|boolean; min?; max?; step? };
```
