# timeline.command op 目录与编排模式

> `timeline.command` 是唯一写入口：`{ op: { type, payload, baseVersion? } }`。每个 op 落统一日志（可 `history.undo`）、version +1，返回 `{ version, seq, result }`。时间字段一律秒。

## op 目录

### 元素
| type | payload | 说明 |
|---|---|---|
| `insert` | `{ sceneId?, trackId?\|trackType?, element: { type, name?, mediaId?/componentId?/definitionId?/effectType?/sourceType?/sourceUrl?, content?, params?, startSec, durationSec, trimStartSec?, trimEndSec?, hidden? }, index? }` | 放元素；`trackType` 缺省按元素类型推导；返回 `result.element = { trackId, elementId }`。视频/图片放主轨，文字放 text 轨，音频放 audio 轨，组件放 graphic 轨 |
| `delete` | `{ refs: [{ trackId, elementId }] }` | 批量删除 |
| `param` | `{ ref, params: { key: value }, atSec?, fields? }` | 设参数；`atSec` 语义见 keyframes.md（D1） |
| `trim` | `{ ref, startSec?, durationSec?, trimStartSec?, trimEndSec?, ripple? }` | 裁剪/位移；`ripple:true` 平移后续同轨元素 |
| `split` | `{ ref, atSec, retainSide: "both"\|"left"\|"right" }` | 在 `atSec` 切分；返回左右 refs |
| `keyframe-upsert` | `{ ref, path, atSec, value, segmentToNext? }` | 在 `atSec` 落/更新关键帧 |
| `keyframe-remove` | `{ ref, path, atSec? }` | 删指定时刻或整条路径的关键帧 |

### 轨道
| type | payload |
|---|---|
| `track-add` | `{ type: "video"\|"text"\|"audio"\|"graphic"\|"effect", name?, index? }` |
| `track-remove` | `{ trackId }`（非空轨拒绝） |
| `track-mute` | `{ trackId, muted? }`（缺省切换） |
| `track-visible` | `{ trackId, hidden? }`（缺省切换） |

### 场景 / 书签
| type | payload |
|---|---|
| `scene-create` | `{ name?, isMain? }` |
| `scene-rename` | `{ sceneId, name }` |
| `scene-delete` | `{ sceneId }`（主场景禁止） |
| `bookmark-add` | `{ sceneId?, timeSec, note? }` |
| `bookmark-remove` | `{ sceneId?, timeSec }` |

### 项目
| type | payload |
|---|---|
| `settings` | `{ fps?, canvasSize?, background? }`（等价 `project.updateSettings`） |

## 编排模式

### 粗剪（铺稿 → 精修）
```text
film.package.import → 时间线草稿        # AI 短片交接包（可选起点）
timeline.read → 现状                    # 轨道 + clips
project.lock                            # 多步会话
  element.insert { video → main 轨 }    # 素材落主轨
  element.trim { 裁剪，ripple }         # 去头去尾
  element.split { atSec }               # 打点切分，删多余段
  element.insert { text → 标题 }        # 字幕/标题
  element.insert { audio → 配音 }       # 旁白/音乐
  keyframe-upsert { opacity / transform }  # 入场退场动画
project.unlock
timeline.validate                       # 零违反
preview.frame(t)                        # 视觉验收
export.start({ mode: "headless" })      # 出片
```

### 变速 / 音频
- 变速：先 `element.trim` 保持 duration 语义；如需 retime 语义（rate 0.01–5x），通过 `element.get` 读取当前 `retime` 后用 `param.fields.retime` 设置（v1 目录以 trim/split 为主，retime 字段可经 `param` 的 `fields` 直接写）。

### 冲突处理
- 收到 `{ conflict, currentVersion, opsSince }`：`timeline.read`（或 `project.get`）重读，按 `opsSince` 理解他人变更后重放自己的 op。
- 每次命令前记录上次 `version`，作为下一次 `baseVersion`。

## 注意事项

- 一次 `timeline.command` 只放一个 op；批量操作用多次调用（每步可 undo）。
- `insert` 的元素 id 由后台确定性生成（`el-ai<seq>-<n>`）；redo 复用存储的 id，幂等。
- 所有时间字段用秒；`durationSec` 至少 0.001。
