# 镜头配方库（recut.editor · 时间线 op 版）

> 与 remotion-studio `shot-recipes/` 同源，但实现从"代码"换成"时间线 op"：每个配方是一串 `timeline.command`（insert / param / keyframe-upsert / trim / split）+ 具体秒数与参数值。时长单位秒；`ref` 来自 insert/read 返回值。
> 一个镜头只用一个配方；相邻 scene 不重复同一种语法。

## 总则

- 关键帧路径：`opacity`、`transform.scaleX/Y`、`transform.positionX/Y`、`transform.rotate`；文字额外 `content/fontSize/color/letterSpacing`。
- 每个配方给出"主配方"；把 durationSec / 关键帧时间 / 位移幅度按素材与预设（`directing.md` 一）微调。
- 复杂需求（粒子、字形描画、shader 感）→ `component.define` 写 AI 临时组件，再 `insert {type:"component"}`。

---

## 开场

### 1. 标题淡入浮起 fade-up-title
**适用**：片头/章节标题；能量低-中。
```text
timeline.command { op: { type:"insert", payload:{ element:{ type:"text", content:"主标题", startSec:0, durationSec:4, params:{ fontSize:96, color:"#FFFFFF", textAlign:"center" } } } } }
# 入场：opacity 0→1，positionY 40→0，0–0.8s
keyframe-upsert { ref, path:"opacity", atSec:0, value:0 }
keyframe-upsert { ref, path:"opacity", atSec:0.8, value:1 }
keyframe-upsert { ref, path:"transform.positionY", atSec:0, value:40 }
keyframe-upsert { ref, path:"transform.positionY", atSec:0.8, value:0 }
# 落定后 hold ≥1s（0.8–2s 无动作），2s 后可退场
keyframe-upsert { ref, path:"opacity", atSec:2.5, value:1 }
keyframe-upsert { ref, path:"opacity", atSec:3.2, value:0 }
```
**坑**：入场后立刻动 = 没呼吸；positionY 位移过大（>60）读作"跳"。

### 2. 画面缩放显影 scale-reveal
**适用**：照片/静态图开场；能量中。
```text
timeline.command { op: { type:"insert", payload:{ element:{ type:"image", mediaId:"<assetId>", startSec:0, durationSec:4 } } } }
keyframe-upsert { ref, path:"opacity", atSec:0, value:0 }
keyframe-upsert { ref, path:"opacity", atSec:0.5, value:1 }
keyframe-upsert { ref, path:"transform.scaleX", atSec:0, value:0.92 }
keyframe-upsert { ref, path:"transform.scaleY", atSec:0, value:0.92 }
keyframe-upsert { ref, path:"transform.scaleX", atSec:0.8, value:1 }
keyframe-upsert { ref, path:"transform.scaleY", atSec:0.8, value:1 }
```
**坑**：scale 从 0 起 = 廉价；0.88–0.95 起才有"呼吸"。

---

## 转场（两段素材 A/B 之间）

### 3. 交叉淡化 crossfade
**适用**：舒缓/信息型段落；能量低。
```text
# A 占 0–3s，B 占 2.5–6s（重叠 0.5s），A 轨道在 B 之上
A: keyframe-upsert { ref:A, path:"opacity", atSec:2.5, value:1 }
A: keyframe-upsert { ref:A, path:"opacity", atSec:3, value:0 }
B: keyframe-upsert { ref:B, path:"opacity", atSec:2.5, value:0 }
B: keyframe-upsert { ref:B, path:"opacity", atSec:3, value:1 }
```
**坑**：重叠 >0.8s 读作"叠化"而非"转场"；强鼓点曲改用硬切（见配方 8）。

### 4. 滑动擦除 slide-wipe
**适用**：产品对比/左右关系；能量中。
```text
# 画布宽 W；B 从画面右缘滑入，A 滑出左缘，各 0.6s
A: keyframe-upsert { ref:A, path:"transform.positionX", atSec:2.4, value:0 }
A: keyframe-upsert { ref:A, path:"transform.positionX", atSec:3, value:-W }
B: keyframe-upsert { ref:B, path:"transform.positionX", atSec:2.4, value:W }
B: keyframe-upsert { ref:B, path:"transform.positionX", atSec:3, value:0 }
```
**坑**：W 必须等于画布宽（`project.get` 的 canvasSize），用画面半宽会留缝。

### 5. 缩放爆闪 zoom-burst
**适用**：节奏强/高潮点；能量高。
```text
A: keyframe-upsert { ref:A, path:"transform.scaleX", atSec:2.5, value:1 }
A: keyframe-upsert { ref:A, path:"transform.scaleX", atSec:3, value:1.35 }
A: keyframe-upsert { ref:A, path:"opacity", atSec:3, value:0 }
B: keyframe-upsert { ref:B, path:"transform.scaleX", atSec:2.5, value:0.9 }
B: keyframe-upsert { ref:B, path:"transform.scaleX", atSec:3, value:1 }
B: keyframe-upsert { ref:B, path:"opacity", atSec:2.5, value:0 }
B: keyframe-upsert { ref:B, path:"opacity", atSec:3, value:1 }
```

---

## 运镜（静态图/长镜头）

### 6. 推近 push-in
**适用**：主体强调；能量低-中。
```text
insert image { startSec:0, durationSec:4 }
keyframe-upsert { ref, path:"transform.scaleX", atSec:0, value:1 }
keyframe-upsert { ref, path:"transform.scaleY", atSec:0, value:1 }
keyframe-upsert { ref, path:"transform.scaleX", atSec:4, value:1.15 }
keyframe-upsert { ref, path:"transform.scaleY", atSec:4, value:1.15 }
```
**坑**：只推 scale 不调 position → 中心感；需要向主体偏移时 position 同向补。

### 7. 横移扫视 pan-reveal
**适用**：宽幅图/长场景；能量中。
```text
# scale 1.1 给左右余量，positionX 从左到右
keyframe-upsert { ref, path:"transform.scaleX", atSec:0, value:1.1 }
keyframe-upsert { ref, path:"transform.scaleY", atSec:0, value:1.1 }
keyframe-upsert { ref, path:"transform.positionX", atSec:0, value:200 }
keyframe-upsert { ref, path:"transform.positionX", atSec:4, value:-200 }
```

---

## 节奏

### 8. 卡点硬切 montage / beat-cut
**适用**：强鼓点曲目；能量高。先读 `music-beat-sync.md` 拿到拍号秒表 `beatT(n)`。
```text
# 假设 BPM=120 → 拍长 0.5s，4 拍一镜 = 2s
insert image A { startSec:beatT(0), durationSec:2 }
insert image B { startSec:beatT(4), durationSec:2 }
insert image C { startSec:beatT(8), durationSec:2 }
# 每镜内部给一次轻 push-in 或 opacity 闪入，切点精确落在拍号
```
**坑**：切点必须落整数拍（±0.03s）；半拍钉点必须有能量数据支持，不凭听感。

### 9. 落定呼吸 breathing-hold
**适用**：任何 scene 收束；能量低。
```text
# 主元素落定后，0.5–1s 内无任何关键帧动作；批量元素收尾留 ≥0.5s 静止
# 全片最后一镜：主标题落定后 hold ≥1s 再淡出
keyframe-upsert { ref, path:"opacity", atSec:5, value:1 }
keyframe-upsert { ref, path:"opacity", atSec:6.2, value:0 }   # 6.2–5 = 1.2s 静止
```

---

## 注意力

### 10. 聚光强调 spotlight
**适用**：关键证据/数字强调；能量中。
```text
# 背景层 opacity 1→0.5（dim），前景文字/数字 opacity 0→1 + scale 1→1.08
bg: keyframe-upsert { ref:bg, path:"opacity", atSec:1, value:1 }
bg: keyframe-upsert { ref:bg, path:"opacity", atSec:1.5, value:0.5 }
fg: keyframe-upsert { ref:fg, path:"opacity", atSec:1.2, value:0 }
fg: keyframe-upsert { ref:fg, path:"opacity", atSec:1.8, value:1 }
fg: keyframe-upsert { ref:fg, path:"transform.scaleX", atSec:1.2, value:1 }
fg: keyframe-upsert { ref:fg, path:"transform.scaleX", atSec:1.8, value:1.08 }
```
**坑**：背景 dim 到 <0.4 会读作"另一层遮罩"；dim + 高亮同时只留一处焦点。

---

## 配方选择速查

| 需求 | 配方 |
|---|---|
| 片头/标题登场 | fade-up-title（安静）/ scale-reveal（动态） |
| 段落切换·舒缓 | crossfade |
| 段落切换·对比 | slide-wipe |
| 高潮/强拍 | zoom-burst 或 beat-cut |
| 静态素材的呼吸感 | push-in / pan-reveal |
| 数字/证据强调 | spotlight |
| 收束 | breathing-hold |
