/**
 * @recut/runtime —— AI 组件唯一允许的外部 import（SDK）。
 * 自包含 d.ts：构建期 tsc 类型检查无需安装任何依赖。
 * 运行时由宿主 import map/prelude 解析到与编辑器同一 React/R3F/three 实例。
 */

declare module "@recut/runtime/jsx-runtime" {
	export const jsx: any;
	export const jsxs: any;
	export const Fragment: any;
}

declare module "@recut/runtime" {
	export type ComponentSurface = "html" | "react" | "r3f";

	export interface AnimApi {
		lerp(a: number, b: number, u: number, opts?: { ease?: string }): number;
		lerpColor(c1: string, c2: string, u: number): string;
		seq(keys: Array<[number, number]>, u: number): number;
		pulse(u: number, opts?: { speed?: number; phase?: number }): number;
	}

	export type ParamValue = number | string | boolean;
	export type ParamValues = Record<string, ParamValue>;

	export interface ParamDefinition {
		key: string;
		label?: string;
		type: string;
		default: ParamValue;
		min?: number;
		max?: number;
		step?: number;
		group?: string;
		options?: Array<{ value: string; label: string }>;
	}

	export interface ComponentRenderContext {
		world: unknown;
		object: unknown;
		params: ParamValues;
		/** 全局时间（秒）。 */
		time: number;
		/** 相对片段的本地时间（秒）。 */
		localTime: number;
		/** localTime / duration ∈ [0,1]。 */
		progress: number;
		/** 确定性动画工具（t → 值，禁墙钟源）。 */
		anim: AnimApi;
	}

	export const jsx: any;
	export const jsxs: any;
	export const Fragment: any;

	export function useState<S>(initial: S | (() => S)): [S, (value: S | ((prev: S) => S)) => void];
	export function useMemo<T>(factory: () => T, deps?: ReadonlyArray<unknown>): T;
	export function useRef<T>(initial: T): { current: T };
	export function useCallback<T extends (...args: never[]) => unknown>(
		fn: T,
		deps?: ReadonlyArray<unknown>,
	): T;
	export function useEffect(effect: () => void | (() => void), deps?: ReadonlyArray<unknown>): void;
	export function useThree(): any;

	export const THREE: any;
	export function useCanvasTexture(
		draw: (ctx: any, width: number, height: number) => void,
		width: number,
		height: number,
	): any;

	export const anim: AnimApi;
	export function num(value: unknown, fallback: number): number;
	export function str(value: unknown, fallback: string): string;
	export function bool(value: unknown, fallback: boolean): boolean;
}

// 全局 JSX 内置元素统一放宽（r3f 与 DOM；组件内容由运行时校验）
declare namespace JSX {
	interface IntrinsicElements {
		[elem: string]: any;
	}
}

